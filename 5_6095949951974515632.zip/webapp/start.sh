#!/usr/bin/env bash
# JATAYU one-shot launcher: backend (:8000) + frontend (:3000)
set -e
cd "$(dirname "$0")"

echo "[1/3] Backend deps..."
cd backend
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q -r requirements.txt || \
  ./venv/bin/pip install -q opencv-python-headless numpy pydantic pydantic-settings fastapi uvicorn

echo "[2/3] Starting pipeline on :8000 (DETECTOR=${DETECTOR:-auto})..."
HEADLESS=1 PYTHONPATH=app nohup ./venv/bin/python app/main.py > ../backend.log 2>&1 &
cd ..

echo "[3/3] Frontend on :3000..."
cd frontend
[ -d node_modules ] || npm install
npm run build
npm run preview
