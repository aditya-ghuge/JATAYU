import os


def get_detector(conf_threshold: float = 0.5):
    """
    Factory: returns the real YOLO detector, or the mock detector when
    DETECTOR=mock (PRD Phase 13) or when ultralytics/torch is unavailable.
    """
    want_mock = os.environ.get("DETECTOR", "").lower() == "mock"
    if not want_mock:
        try:
            from .detector import YOLODetector

            return YOLODetector(conf_threshold=conf_threshold)
        except Exception as exc:
            print(f"[detection] YOLO unavailable ({exc}) -> falling back to MockDetector")
    from .mock import MockDetector

    return MockDetector(conf_threshold=conf_threshold)


__all__ = ["get_detector", "Detection"]

from .models import Detection  # noqa: E402  (re-exported for engines)
