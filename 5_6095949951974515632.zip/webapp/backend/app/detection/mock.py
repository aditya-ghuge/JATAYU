"""
MOCK DETECTOR (PRD Phase 13 — "Create a mock mode").

Produces synthetic person / FIRE / SMOKE detections with stable track IDs so the
whole downstream pipeline (tracking, zones, crowd, evacuation, hazards, events,
JSON, API) can be exercised WITHOUT YOLO/torch installed.

Enable with:   DETECTOR=mock python app/main.py
"""

import math
import random
import time
from typing import List

from .models import Detection


class MockDetector:
    def __init__(self, conf_threshold: float = 0.5, n_people: int = 12):
        self.conf_threshold = conf_threshold
        self.n_people = n_people
        self.t0 = time.time()
        self._agents = []
        for i in range(n_people):
            self._agents.append(
                {
                    "id": i + 1,
                    "phase": random.random() * math.tau,
                    "speed": 0.25 + random.random() * 0.55,
                    "rx": 0.10 + random.random() * 0.72,
                    "ry": 0.14 + random.random() * 0.66,
                    "amp": 0.05 + random.random() * 0.12,
                }
            )

    def predict(self, frame) -> List[Detection]:
        h, w = frame.shape[:2]
        t = time.time() - self.t0
        out: List[Detection] = []

        for a in self._agents:
            # smooth lissajous drift so people move between zones over time
            cx = (a["rx"] + a["amp"] * math.sin(t * a["speed"] + a["phase"])) * w
            cy = (a["ry"] + a["amp"] * math.cos(t * a["speed"] * 0.8 + a["phase"])) * h
            bw, bh = w * 0.035, h * 0.16
            out.append(
                Detection(
                    class_id=0,
                    class_name="person",
                    confidence=round(0.68 + 0.28 * random.random(), 3),
                    bbox=(
                        max(0, int(cx - bw / 2)),
                        max(0, int(cy - bh / 2)),
                        min(w - 1, int(cx + bw / 2)),
                        min(h - 1, int(cy + bh / 2)),
                    ),
                    track_id=a["id"],
                )
            )

        # Ignite a fire after 12s, add smoke after 20s — drives hazard confirmation,
        # UNSAFE_MOVEMENT and the critical-alert path end to end.
        if t > 12:
            fx, fy = int(w * 0.80), int(h * 0.72)
            out.append(
                Detection(
                    class_id=67, class_name="FIRE",
                    confidence=round(0.88 + 0.10 * random.random(), 3),
                    bbox=(fx - 40, fy - 40, fx + 40, fy + 40), track_id=9001,
                )
            )
        if t > 20:
            sx, sy = int(w * 0.72), int(h * 0.62)
            out.append(
                Detection(
                    class_id=41, class_name="SMOKE",
                    confidence=round(0.78 + 0.14 * random.random(), 3),
                    bbox=(sx - 55, sy - 55, sx + 55, sy + 55), track_id=9002,
                )
            )

        return [d for d in out if d.confidence >= self.conf_threshold]
