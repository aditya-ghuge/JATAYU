import cv2
from .base import BaseVideoSource


class FileVideoSource(BaseVideoSource):
    """Video-file source. Loops by default so demos run continuously."""

    def __init__(self, filepath: str, loop: bool = True):
        super().__init__()
        self.filepath = filepath
        self.loop = loop

    def start(self):
        self.cap = cv2.VideoCapture(self.filepath)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open video file: {self.filepath}")

    def read(self):
        ret, frame = super().read()
        if not ret and self.loop and self.cap is not None:
            # rewind to the first frame and try once more
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ret, frame = super().read()
        return ret, frame
