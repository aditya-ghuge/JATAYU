"""
JATAYU / PS14 — CCTV Disaster Intelligence pipeline.

    CCTV -> OpenCV -> YOLO -> Tracker -> Zones -> Crowd/Evac/Hazard -> JSON/API

Runs the vision loop on the main thread and the FastAPI server on a daemon
thread, so the React command center can consume /state, /events and /video_feed.

Run headless (no GUI window — required on servers / containers):
    HEADLESS=1 python app/main.py
"""

import datetime
import os
import sys
import threading
import time
import uuid

import cv2

from api import run_server, store
from config import settings
from crowd import CrowdEngine
from detection import get_detector
from evacuation import EvacuationEngine
from hazards import HazardEngine
from tracking import PersonTracker
from video import get_video_source
from zones import ZoneManager

SCHEMA_VERSION = "1.0"
CAMERA_ID = os.environ.get("CAMERA_ID", "CAM-01")
HEADLESS = os.environ.get("HEADLESS", "0") in ("1", "true", "True")
CONFIG_DIR = os.environ.get("JATAYU_CONFIG_DIR", "config")
ZONES_PATH = os.path.join(CONFIG_DIR, "zones.json")
EXITS_PATH = os.path.join(CONFIG_DIR, "exits.json")


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def emit_event(event_type: str, priority: str, data: dict):
    """Push a schema-compliant event into the shared store."""
    store.add_event(
        {
            "event_id": f"EVT-{str(uuid.uuid4())[:8].upper()}",
            "timestamp": now_iso(),
            "type": event_type,
            "priority": priority,
            "data": data,
        }
    )


def main():
    print("=" * 62)
    print(" JATAYU · PS14 CCTV Disaster Intelligence Module")
    print("=" * 62)
    print(f" Source type : {settings.VIDEO_SOURCE_TYPE}")
    print(f" Source path : {settings.VIDEO_SOURCE_PATH}")
    print(f" Headless    : {HEADLESS}")

    print("\n[1/5] Loading YOLO detector...")
    detector = get_detector(conf_threshold=0.5)

    print("[2/5] Initialising tracker...")
    tracker = PersonTracker(history_length=30, max_age=30)

    print("[3/5] Loading zones and exits...")
    zone_manager = ZoneManager(ZONES_PATH)
    crowd_engine = CrowdEngine(zone_manager)
    evac_engine = EvacuationEngine(EXITS_PATH)
    hazard_engine = HazardEngine(zone_manager, confirm_threshold=15, lose_threshold=10)

    print("[4/5] Starting API server on http://0.0.0.0:8000 ...")
    api_thread = threading.Thread(
        target=run_server, kwargs={"host": "0.0.0.0", "port": 8000}, daemon=True
    )
    api_thread.start()

    print("[5/5] Opening video source...")
    try:
        source = get_video_source(settings.VIDEO_SOURCE_TYPE, settings.VIDEO_SOURCE_PATH)
        source.start()
    except Exception as exc:
        print(f"  !! Error initialising video source: {exc}")
        emit_event("CAMERA_OFFLINE", "CRITICAL", {"message": str(exc)})
        sys.exit(1)

    current_source_type = settings.VIDEO_SOURCE_TYPE
    print("\n>>> Pipeline running. Open the dashboard, or press 'q' in the window to quit.\n")
    emit_event("SYSTEM", "INFO", {"message": "CCTV pipeline started"})

    alert_active_until = 0.0
    last_alert_msg = ""
    confirmed_hazard_keys: set = set()
    prev_zone_by_track: dict = {}

    try:
        while True:
            # ----------------------------------------------------------
            # Handle control requests coming from the API / dashboard
            # ----------------------------------------------------------
            if store.consume_reset():
                evac_engine.evacuated_ids.clear()
                evac_engine.entered_ids.clear()
                evac_engine.initial_population = 0
                print("[control] Evacuation counters reset.")
                emit_event("SYSTEM", "INFO", {"message": "Evacuation counters reset"})

            reload_what = store.consume_reload()
            if reload_what in ("zones", "exits"):
                if reload_what == "zones":
                    zone_manager = ZoneManager(ZONES_PATH)
                    crowd_engine = CrowdEngine(zone_manager)
                    hazard_engine = HazardEngine(
                        zone_manager, confirm_threshold=15, lose_threshold=10
                    )
                else:
                    evac_engine = EvacuationEngine(EXITS_PATH)
                print(f"[control] Reloaded {reload_what} configuration.")
                emit_event("SYSTEM", "INFO", {"message": f"{reload_what} reloaded"})

            src_req = store.consume_source()
            if src_req:
                new_type, new_path = src_req
                print(f"[control] Switching source -> {new_type}: {new_path}")
                try:
                    source.release()
                    source = get_video_source(new_type, new_path)
                    source.start()
                    current_source_type = new_type
                    emit_event(
                        "SYSTEM", "INFO", {"message": f"Source switched to {new_type}"}
                    )
                except Exception as exc:
                    print(f"  !! Source switch failed: {exc}")
                    emit_event("CAMERA_OFFLINE", "CRITICAL", {"message": str(exc)})

            # ----------------------------------------------------------
            # Read frame
            # ----------------------------------------------------------
            ret, frame = source.read()
            if not ret:
                print("End of stream / failed frame read.")
                emit_event("CAMERA_OFFLINE", "HIGH", {"message": "Frame read failed"})
                break

            fps = source.get_fps()
            h, w = frame.shape[:2]

            # ----------------------------------------------------------
            # Inference + engines
            # ----------------------------------------------------------
            detections = detector.predict(frame)
            person_detections = [d for d in detections if d.class_name == "person"]

            tracked_people = tracker.update(person_detections)
            hazard_states = hazard_engine.update(detections)

            # assign zones before computing crowd metrics
            for person in tracked_people:
                person.current_zone = zone_manager.get_zone_for_point(person.history[-1])

            crowd_metrics = crowd_engine.compute_metrics(tracked_people)
            evac_metrics = evac_engine.update(tracked_people)

            # ----------------------------------------------------------
            # Hazard confirmation events (fire once per hazard)
            # ----------------------------------------------------------
            live_keys = set()
            for hz in hazard_states:
                key = (hz.type, hz.zone_id)
                if hz.status == "CONFIRMED":
                    live_keys.add(key)
                    if key not in confirmed_hazard_keys:
                        confirmed_hazard_keys.add(key)
                        emit_event(
                            f"{hz.type}_DETECTED",
                            "CRITICAL",
                            {
                                "message": f"{hz.type} CONFIRMED in {hz.zone_id}",
                                "zone": hz.zone_id,
                                "confidence": round(hz.confidence, 3),
                            },
                        )
            confirmed_hazard_keys &= live_keys

            hazard_zone_ids = {hz.zone_id for hz in hazard_states if hz.status == "CONFIRMED"}

            # ----------------------------------------------------------
            # Unsafe movement — person entering a confirmed-hazard zone
            # ----------------------------------------------------------
            for person in tracked_people:
                prev = prev_zone_by_track.get(person.track_id)
                cur = person.current_zone
                if prev and cur and prev != cur and cur in hazard_zone_ids:
                    emit_event(
                        "UNSAFE_MOVEMENT",
                        "HIGH",
                        {
                            "message": f"Subject #{person.track_id} moved into hazard zone {cur}",
                            "track_id": person.track_id,
                            "from_zone": prev,
                            "to_zone": cur,
                            "confidence": round(person.confidence, 3),
                        },
                    )
                if cur:
                    prev_zone_by_track[person.track_id] = cur

            # ----------------------------------------------------------
            # Build the state payload consumed by the dashboard
            # ----------------------------------------------------------
            evacuated = evac_metrics.get("evacuated", 0)
            initial = evac_metrics.get("initial_population", 0)
            visible = crowd_metrics.get("total_visible", 0)

            state_json = {
                "schema_version": SCHEMA_VERSION,
                "timestamp": now_iso(),
                "camera_id": CAMERA_ID,
                "camera_status": "ONLINE",
                "source_type": current_source_type,
                "fps": round(fps, 2),
                "frame_size": [w, h],
                "population": {
                    "total_visible": visible,
                    "tracked": len(tracked_people),
                    "evacuated": evacuated,
                    "entered": evac_metrics.get("entered", 0),
                    "initial_population": initial,
                    "evacuation_percentage": evac_metrics.get("evacuation_percentage", 0),
                    "remaining": max(0, initial - evacuated),
                    "potentially_unaccounted": max(0, initial - evacuated - visible),
                    "zones": crowd_metrics.get("zones", []),
                },
                "hazards": [
                    {
                        "type": hz.type,
                        "zone": hz.zone_id,
                        "confidence": round(hz.confidence, 3),
                        "status": hz.status,
                        "frames_detected": hz.frames_detected,
                    }
                    for hz in hazard_states
                ],
                "tracks": [
                    {
                        "track_id": p.track_id,
                        "bbox": list(p.bbox),
                        "confidence": round(p.confidence, 3),
                        "current_zone": p.current_zone,
                        "history": [list(pt) for pt in p.history[-14:]],
                    }
                    for p in tracked_people
                ],
            }
            store.update_state(state_json)

            # Unsafe-entry alerts from the evacuation engine
            for alert in evac_metrics.get("alerts", []):
                emit_event("UNSAFE_ENTRY", "CRITICAL", {"message": alert})

            # ==========================================================
            # ANNOTATION — drawn once, then streamed via /video_feed
            # ==========================================================
            overlay = frame.copy()
            for zone in zone_manager.get_all_zones():
                color = (0, 0, 255) if zone.zone_id in hazard_zone_ids else (255, 0, 0)
                cv2.polylines(overlay, [zone.np_polygon], True, color, 2)
                cv2.fillPoly(overlay, [zone.np_polygon], color)
            cv2.addWeighted(overlay, 0.2, frame, 0.8, 0, frame)

            for ex in evac_engine.exits:
                pt1, pt2 = tuple(ex["line"][0]), tuple(ex["line"][1])
                cv2.line(frame, pt1, pt2, (0, 255, 0), 4)
                cv2.putText(
                    frame, ex["name"], pt1, cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2
                )

            for person in tracked_people:
                x1, y1, x2, y2 = person.bbox
                in_hazard = person.current_zone in hazard_zone_ids
                box_color = (0, 0, 255) if in_hazard else (0, 255, 0)
                cv2.rectangle(frame, (x1, y1), (x2, y2), box_color, 2)
                cv2.putText(
                    frame,
                    f"#{person.track_id} ({person.current_zone or 'NO_ZONE'})",
                    (x1, max(y1 - 10, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    box_color,
                    2,
                )
                for i in range(1, len(person.history)):
                    cv2.line(frame, person.history[i - 1], person.history[i], (0, 255, 255), 2)

            for hz in hazard_states:
                if hz.status == "CONFIRMED":
                    if int(time.time() * 4) % 2 == 0:
                        cv2.rectangle(frame, (0, 0), (w, h), (0, 0, 255), 10)
                    text = f"CRITICAL: {hz.type} IN {hz.zone_id}!"
                    (tw, _), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 1.2, 3)
                    cv2.putText(
                        frame, text, ((w - tw) // 2, 100),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3,
                    )
                elif hz.status == "DETECTING":
                    cv2.putText(
                        frame, f"Detecting {hz.type}...", (10, h - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 165, 255), 2,
                    )

            # HUD
            cv2.putText(frame, f"FPS: {fps:.1f}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(
                frame,
                f"Evacuated: {evacuated}/{initial} ({evac_metrics['evacuation_percentage']}%)",
                (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2,
            )
            cv2.putText(frame, f"Entered (HAZARD): {evac_metrics['entered']}", (10, 85),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

            y_off = 115
            for zm in crowd_metrics["zones"]:
                cv2.putText(
                    frame, f"{zm['name']}: {zm['people']} ({zm['crowd_level']})",
                    (10, y_off), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2,
                )
                y_off += 26

            if evac_metrics["alerts"]:
                alert_active_until = time.time() + 3
                last_alert_msg = evac_metrics["alerts"][-1]
            if time.time() < alert_active_until and int(time.time() * 4) % 2 == 0:
                text = f"ALERT: {last_alert_msg}"
                (tw, _), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 1.2, 3)
                cv2.putText(frame, text, ((w - tw) // 2, h // 2),
                            cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)

            # Publish the annotated frame for /video_feed
            ok, buffer = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ok:
                store.update_frame(buffer.tobytes())

            # Local GUI window (skipped when headless)
            if not HEADLESS:
                cv2.imshow("JATAYU CCTV", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            else:
                time.sleep(0.005)

    except KeyboardInterrupt:
        print("\nInterrupted by user.")
    finally:
        print("Cleaning up...")
        try:
            source.release()
        except Exception:
            pass
        if not HEADLESS:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
