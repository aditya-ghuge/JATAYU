"""
FastAPI surface for the JATAYU / PS14 CCTV Disaster Intelligence module.

Consumed by the React command center in ../frontend.

Endpoints
---------
GET  /health       liveness + pipeline telemetry
GET  /state        current population / zones / hazards / tracks
GET  /events       rolling buffer of the last 100 events
GET  /video_feed   annotated MJPEG stream
GET  /zones        zone polygon configuration
POST /zones        overwrite zone configuration (hot reload)
GET  /exits        virtual exit line configuration
POST /exits        overwrite exit configuration (hot reload)
POST /reset        reset evacuation counters
POST /config       switch the video source at runtime
"""

import json
import os
import time
from typing import Any, Dict, List, Optional

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

from .store import store

APP_START = time.time()

CONFIG_DIR = os.environ.get("JATAYU_CONFIG_DIR", "config")
ZONES_PATH = os.path.join(CONFIG_DIR, "zones.json")
EXITS_PATH = os.path.join(CONFIG_DIR, "exits.json")

app = FastAPI(
    title="JATAYU CCTV Disaster Intelligence API",
    description="Structured real-time disaster intelligence derived from CCTV footage.",
    version="1.0.0",
)

# ---------------------------------------------------------------------------
# CORS — required so the browser-based dashboard can call this service.
# The dashboard is served from a different origin (Vite / static host),
# so without this every fetch() is blocked by the browser.
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your dashboard origin in production
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------
class SourceConfig(BaseModel):
    source_type: str  # webcam | file | rtsp
    source_path: str


# ---------------------------------------------------------------------------
# Read endpoints
# ---------------------------------------------------------------------------
@app.get("/health")
def get_health() -> Dict[str, Any]:
    state = store.get_state()
    return {
        "status": "ok",
        "version": "1.0.0",
        "uptime_seconds": round(time.time() - APP_START, 1),
        "camera_status": state.get("camera_status", "ONLINE" if state else "STARTING"),
        "source_type": state.get("source_type"),
        "fps": state.get("fps"),
        "detector": "YOLOv8n · ByteTrack",
        "has_frame": store.get_frame() is not None,
        "events_buffered": len(store.get_events()),
    }


@app.get("/state")
def get_state() -> Dict[str, Any]:
    return store.get_state()


@app.get("/events")
def get_events() -> Dict[str, Any]:
    return {"events": store.get_events()}


def _read_json(path: str, default: Any) -> Any:
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except Exception as exc:  # pragma: no cover
        print(f"[api] failed reading {path}: {exc}")
        return default


@app.get("/zones")
def get_zones() -> List[Dict[str, Any]]:
    return _read_json(ZONES_PATH, [])


@app.get("/exits")
def get_exits() -> List[Dict[str, Any]]:
    return _read_json(EXITS_PATH, [])


# ---------------------------------------------------------------------------
# Write endpoints — the pipeline picks these up via store.pending_*
# ---------------------------------------------------------------------------
@app.post("/zones")
def set_zones(zones: List[Dict[str, Any]]) -> Dict[str, Any]:
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(ZONES_PATH, "w") as f:
            json.dump(zones, f, indent=2)
        store.request_reload("zones")
        return {"ok": True, "count": len(zones)}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@app.post("/exits")
def set_exits(exits: List[Dict[str, Any]]) -> Dict[str, Any]:
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(EXITS_PATH, "w") as f:
            json.dump(exits, f, indent=2)
        store.request_reload("exits")
        return {"ok": True, "count": len(exits)}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@app.post("/reset")
def reset_counters() -> Dict[str, Any]:
    store.request_reset()
    return {"ok": True, "message": "Evacuation counters will reset on the next frame."}


@app.post("/config")
def set_source(cfg: SourceConfig) -> Dict[str, Any]:
    if cfg.source_type.lower() not in {"webcam", "file", "rtsp"}:
        return JSONResponse(
            {"ok": False, "error": "source_type must be webcam, file or rtsp"},
            status_code=400,
        )
    store.request_source(cfg.source_type.lower(), cfg.source_path)
    return {
        "ok": True,
        "message": f"Switching to {cfg.source_type}: {cfg.source_path}",
    }


# ---------------------------------------------------------------------------
# MJPEG stream
# ---------------------------------------------------------------------------
def generate_frames():
    boundary = b"--frame\r\n"
    while True:
        frame = store.get_frame()
        if frame is not None:
            yield boundary + b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
        time.sleep(0.05)  # ~20 FPS cap to protect CPU


@app.get("/video_feed")
def video_feed():
    return StreamingResponse(
        generate_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={"Cache-Control": "no-store, no-cache, must-revalidate"},
    )


def run_server(host: str = "0.0.0.0", port: int = 8000):
    """Run uvicorn. Designed to be called from a daemon thread in main.py."""
    uvicorn.run(app, host=host, port=port, log_level="error")
