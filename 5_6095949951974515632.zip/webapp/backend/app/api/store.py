"""
Thread-safe shared state between the vision pipeline (main loop) and the
FastAPI server (background thread).

The pipeline WRITES state / events / frames.
The API READS them, and can queue control requests that the pipeline
consumes on its next iteration (reset, source switch, config reload).
"""

import threading
from typing import Any, Dict, List, Optional, Tuple


class StateStore:
    def __init__(self):
        self.lock = threading.Lock()
        self.latest_state: Dict[str, Any] = {}
        self.events: List[Dict[str, Any]] = []
        self.latest_frame: Optional[bytes] = None

        # --- control channel (API -> pipeline) ---
        self._reset_requested = False
        self._reload_requested: Optional[str] = None
        self._source_request: Optional[Tuple[str, str]] = None

    # ------------------------------------------------------------------ state
    def update_state(self, state: Dict[str, Any]):
        with self.lock:
            self.latest_state = state

    def get_state(self) -> Dict[str, Any]:
        with self.lock:
            return dict(self.latest_state)

    # ----------------------------------------------------------------- events
    def add_event(self, event: Dict[str, Any]):
        with self.lock:
            self.events.append(event)
            if len(self.events) > 100:  # ring buffer, prevents memory growth
                self.events.pop(0)

    def get_events(self) -> List[Dict[str, Any]]:
        with self.lock:
            return list(self.events)

    # ----------------------------------------------------------------- frames
    def update_frame(self, frame_bytes: bytes):
        with self.lock:
            self.latest_frame = frame_bytes

    def get_frame(self) -> Optional[bytes]:
        with self.lock:
            return self.latest_frame

    # ---------------------------------------------------------------- control
    def request_reset(self):
        with self.lock:
            self._reset_requested = True

    def consume_reset(self) -> bool:
        with self.lock:
            flag = self._reset_requested
            self._reset_requested = False
            return flag

    def request_reload(self, what: str):
        with self.lock:
            self._reload_requested = what

    def consume_reload(self) -> Optional[str]:
        with self.lock:
            what = self._reload_requested
            self._reload_requested = None
            return what

    def request_source(self, source_type: str, source_path: str):
        with self.lock:
            self._source_request = (source_type, source_path)

    def consume_source(self) -> Optional[Tuple[str, str]]:
        with self.lock:
            req = self._source_request
            self._source_request = None
            return req


# Global singleton shared by the pipeline and the API thread
store = StateStore()
