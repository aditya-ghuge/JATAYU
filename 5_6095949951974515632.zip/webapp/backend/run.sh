#!/usr/bin/env bash
# Run the vision pipeline + API. Use DETECTOR=mock to skip torch.
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q -r requirements.txt 2>/dev/null || true
HEADLESS="${HEADLESS:-1}" PYTHONPATH=app ./venv/bin/python app/main.py
