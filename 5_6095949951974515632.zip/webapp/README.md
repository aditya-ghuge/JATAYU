# JATAYU — PS14 CCTV Disaster Intelligence & Evacuation Monitoring

A production-grade command center for the PS14 CCTV disaster-intelligence module.
The React frontend consumes the **exact JSON contract** your Python/OpenCV/YOLO backend
already produces, so every feature is wired end-to-end.

```
CCTV → OpenCV → YOLO → Tracker → Zones → Crowd/Evac/Hazard → JSON/API → THIS DASHBOARD
```

---

## 1. Quick Start

### Backend (vision pipeline + API on :8000)

```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Real YOLO detection (needs torch, ~500 MB)
python app/main.py

# No-GPU / no-torch demo — mock detector, full pipeline (PRD Phase 13)
HEADLESS=1 DETECTOR=mock python app/main.py
```

Configure the source with `backend/.env`:

```env
VIDEO_SOURCE_TYPE=file        # webcam | file | rtsp
VIDEO_SOURCE_PATH=samples/demo.mp4
```

### Frontend (dashboard on :3000)

```bash
cd frontend
npm install
npm run build && npm run preview     # production
npm run dev                          # hot-reload dev server
```

Open **http://localhost:3000**. The dashboard auto-detects the backend within one
poll cycle; if it isn't running it falls back to a built-in simulation so the UI is
always demonstrable.

---

## 2. Completed Features

### Pages

| Route | Page | What it does |
|---|---|---|
| `/` | **Command Center** | 6 KPI cards, live feed + overlays, event stream, zone matrix, evacuation monitor, hazard board, 2 charts |
| `/live` | **Live Feed** | Full-width tactical stream, runtime source switching (webcam/file/RTSP), pipeline telemetry |
| `/zones` | **Zone Control** | Click-to-draw polygon zones & exit lines on the camera FOV, capacity sliders, export `zones.json`/`exits.json` |
| `/analytics` | **Analytics** | Composite risk gauge, 6 KPIs, 4 charts (timeline, bars, radar, donut), zone table, SITREP JSON export |
| `/events` | **Event Log** | Severity tiles, search, type filter, unacknowledged-only view, per-event ack, CSV export |
| `/settings` | **Settings** | API base URL, poll interval (250 ms–5 s), audio alerts, force-demo, live endpoint diagnostics |

### Backend feature coverage

| Backend capability | Where it surfaces |
|---|---|
| Person detection + ByteTrack IDs | Bounding boxes with `#id` + confidence on the live canvas |
| Motion history trails | Cyan polyline trails (toggleable) |
| Polygon zones + assignment | Zone Occupancy Matrix, canvas overlay, Zone Control editor |
| Crowd levels (LOW→CRITICAL) | Colour-coded badges, progress bars, bar/radar charts |
| Fire / Smoke / Debris | Hazard Board with **temporal-confirmation progress** (`n/15 frames`) |
| `DETECTING` → `CONFIRMED` | Amber "detecting…" state vs red flashing confirmed state |
| Exit-line crossing (dedup by track) | Evacuation Monitor: evacuated / remaining / unaccounted |
| OUTBOUND vs INBOUND | "Evacuated" vs "Unsafe Entries" (pulsing red when > 0) |
| Evacuation % | Radial gauge + timeline chart |
| `UNSAFE_MOVEMENT`, `CROWD_SURGE`, etc. | Event stream with icons, severity colours, toasts + audio |
| MJPEG `/video_feed` | `<img>` stream with canvas overlay composited on top |

### UI / animation

- **Buttons**: hover lift + glow, sheen sweep, press scale-down, click ripple, attention pulse-ring, 6 variants × 4 sizes
- Animated counters (cubic ease-out), shimmer progress bars, SVG radial gauges
- Framer Motion route/list transitions, `layoutId` nav indicator, spring toasts
- Live-feed HUD: corner brackets, scan line, `REC ●`, flashing critical banner
- Fully responsive (collapsible sidebar → mobile drawer), semantic HTML, focus rings, `prefers-reduced-motion`

---

## 3. Backend Changes I Made (required for the frontend to work)

Your original backend could **not** be consumed by a browser. I fixed that:

1. **CORS middleware** — without it every browser `fetch()` is blocked. This was a hard blocker.
2. **New endpoints**: `GET /health`, `GET|POST /zones`, `GET|POST /exits`, `POST /reset`, `POST /config`.
3. **`tracks[]` in `/state`** — so the dashboard can draw boxes/trails over the video.
4. **Richer `/state`** — added `schema_version`, `camera_status`, `fps`, `frame_size`, `source_type`, `remaining`, `potentially_unaccounted`, and hazard `status`/`frames_detected`.
5. **Real event emission** — your `main.py` only emitted `UNSAFE_ENTRY`. Now also `FIRE_DETECTED`, `SMOKE_DETECTED`, `UNSAFE_MOVEMENT`, `CAMERA_OFFLINE`, `SYSTEM` (fired once per hazard, not per frame).
6. **Control channel** — the API can queue reset / config-reload / source-switch, consumed by the pipeline on its next frame (thread-safe, no restart needed).
7. **`HEADLESS=1`** — `cv2.imshow` crashes on servers/containers; headless mode skips the GUI window.
8. **Mock detector** (`DETECTOR=mock`) — PRD Phase 13. Runs the full pipeline without torch.
9. **Bug fix — evacuation baseline**: `initial_population` was hardcoded to `10`. Now tracks the peak observed headcount, so evacuation % is meaningful.
10. **Bug fix — zone assignment order**: zones were assigned *after* `compute_metrics()`, so crowd counts used the previous frame's zones. Now assigned first.
11. **Video files loop** — demos no longer die at end-of-file.

---

## 4. API Contract

| Method | Path | Returns |
|---|---|---|
| GET | `/health` | status, uptime, fps, camera status, detector |
| GET | `/state` | population, zones[], hazards[], tracks[] |
| GET | `/events` | `{ events: [...] }` (last 100) |
| GET | `/video_feed` | MJPEG stream |
| GET/POST | `/zones` | zone polygon config |
| GET/POST | `/exits` | exit line config |
| POST | `/reset` | reset evacuation counters |
| POST | `/config` | `{ source_type, source_path }` |

---

## 5. Verified

- ✅ `npm run build` clean, TypeScript strict, 0 errors
- ✅ All 6 routes render with no console/runtime errors
- ✅ Backend LIVE: `/health` `/state` `/events` `/zones` `/exits` `/reset` all 200, CORS `*`, MJPEG 4.5 MB stream
- ✅ End-to-end LIVE confirmed: dashboard showed `LIVE BACKEND · latency 11 ms · CRITICAL · 2 HAZARDS · 85 FPS · CAM-01`, 75 events, `UNSAFE_MOVEMENT` + `UNSAFE_ENTRY` + `FIRE_DETECTED` firing
- ✅ Graceful degradation to DEMO when backend is down

### Two fixes found by testing

- **React error #185 (infinite render)** — a Zustand selector returned `?? []`, creating a new array identity on every store read. Fixed with a stable `EMPTY_ZONES` constant.
- **Silent poll death** — an unguarded `await` in the polling loop meant one throw stopped polling forever. Now wrapped in `try/finally` so the timer always re-arms.

---

## 6. Tech Stack

**Frontend**: React 18 · TypeScript · Vite 5 · Tailwind 3 · Zustand 5 · Framer Motion · Recharts · lucide-react
**Backend**: Python · FastAPI · Uvicorn · OpenCV · YOLOv8 (Ultralytics) · ByteTrack · Pydantic

---

## 7. Not Implemented / Next Steps

- **WebSocket `/ws/live`** (PRD §18 optional) — currently HTTP polling at a configurable 250 ms–5 s. Polling is robust and simple; WS would cut latency and bandwidth.
- **Multi-camera** — UI is built around one `camera_id` (an explicit PRD non-goal for the MVP). Would need a camera selector + per-camera state map.
- **Historical persistence** — telemetry is in-memory (last 90 samples, 100 events); it resets on reload. Add SQLite/Postgres for cross-session analytics.
- **Auth** — no login. Add before exposing publicly, and tighten CORS from `*` to your dashboard origin.
- **Debris/blocked-exit detection** — frontend fully supports `DEBRIS` and `blocked` exits; the backend's YOLO class map covers only FIRE/SMOKE, so it needs a custom-trained model (PRD Phase 8).
- **Drag-to-edit zone vertices** — you can draw and delete zones; moving an existing vertex requires redrawing.
