/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      colors: {
        ink: {
          900: '#070b14', 850: '#0a1020', 800: '#0e1526',
          750: '#131c31', 700: '#18223c', 600: '#232f4e', 500: '#33415f',
        },
        brand: {
          50: '#eef6ff', 100: '#d9ecff', 200: '#bcdfff', 300: '#8ecbff',
          400: '#59adff', 500: '#328bff', 600: '#1b6cf5', 700: '#1455e1',
          800: '#1746b6', 900: '#193e8f',
        },
        safe: '#22c55e',
        warn: '#f59e0b',
        danger: '#ef4444',
        critical: '#dc2626',
        cyan: { 400: '#22d3ee', 500: '#06b6d4' },
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(50,139,255,.25), 0 8px 30px -8px rgba(50,139,255,.45)',
        'glow-danger': '0 0 0 1px rgba(239,68,68,.3), 0 8px 30px -8px rgba(239,68,68,.5)',
        card: '0 1px 0 0 rgba(255,255,255,.04) inset, 0 12px 32px -16px rgba(0,0,0,.8)',
      },
      keyframes: {
        'pulse-ring': {
          '0%': { transform: 'scale(.9)', opacity: '.7' },
          '70%': { transform: 'scale(1.6)', opacity: '0' },
          '100%': { transform: 'scale(1.6)', opacity: '0' },
        },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
        'slide-up': { '0%': { opacity: '0', transform: 'translateY(12px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        'fade-in': { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        'scan-line': { '0%': { top: '0%' }, '100%': { top: '100%' } },
        blink: { '0%,100%': { opacity: '1' }, '50%': { opacity: '.25' } },
        'spin-slow': { to: { transform: 'rotate(360deg)' } },
        'bar-grow': { '0%': { transform: 'scaleX(0)' }, '100%': { transform: 'scaleX(1)' } },
      },
      animation: {
        'pulse-ring': 'pulse-ring 1.8s cubic-bezier(.24,.86,.4,.96) infinite',
        shimmer: 'shimmer 2s infinite',
        'slide-up': 'slide-up .35s cubic-bezier(.16,1,.3,1) both',
        'fade-in': 'fade-in .3s ease both',
        'scan-line': 'scan-line 3.5s linear infinite',
        blink: 'blink 1.2s ease-in-out infinite',
        'spin-slow': 'spin-slow 8s linear infinite',
        'bar-grow': 'bar-grow .6s cubic-bezier(.16,1,.3,1) both',
      },
    },
  },
  plugins: [],
}
