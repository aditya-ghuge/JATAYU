import clsx from 'clsx';
import { AnimatePresence } from 'framer-motion';
import { BellRing, CheckCheck, Download, Filter, Search, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { EventRow } from '../components/dashboard/EventFeed';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Badge, EmptyState, Panel, PanelHeader } from '../components/ui/Primitives';
import { useStore } from '../lib/store';

const PRIORITIES = ['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'] as const;

export default function EventLog() {
  const events = useStore((s) => s.events);
  const acked = useStore((s) => s.acked);
  const ackAll = useStore((s) => s.ackAll);
  const clearAcks = useStore((s) => s.clearAcks);
  const pushToast = useStore((s) => s.pushToast);

  const [priority, setPriority] = useState<(typeof PRIORITIES)[number]>('ALL');
  const [query, setQuery] = useState('');
  const [onlyPending, setOnlyPending] = useState(false);

  const types = useMemo(
    () => [...new Set(events.map((e) => String(e.type)))].sort(),
    [events],
  );
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...events]
      .reverse()
      .filter((e) => priority === 'ALL' || String(e.priority).toUpperCase() === priority)
      .filter((e) => typeFilter === 'ALL' || String(e.type) === typeFilter)
      .filter((e) => !onlyPending || !acked.has(e.event_id))
      .filter(
        (e) =>
          !q ||
          String(e.type).toLowerCase().includes(q) ||
          e.event_id.toLowerCase().includes(q) ||
          String(e.data?.message ?? '').toLowerCase().includes(q) ||
          String(e.data?.zone ?? '').toLowerCase().includes(q),
      );
  }, [events, priority, typeFilter, onlyPending, query, acked]);

  const counts = useMemo(() => {
    const m: Record<string, number> = {};
    for (const e of events) {
      const k = String(e.priority).toUpperCase();
      m[k] = (m[k] ?? 0) + 1;
    }
    return m;
  }, [events]);

  const exportCsv = () => {
    const head = 'event_id,timestamp,type,priority,zone,track_id,message\n';
    const rows = filtered
      .map((e) =>
        [
          e.event_id,
          e.timestamp,
          e.type,
          e.priority,
          e.data?.zone ?? '',
          e.data?.track_id ?? '',
          `"${String(e.data?.message ?? '').replace(/"/g, '""')}"`,
        ].join(','),
      )
      .join('\n');
    const blob = new Blob([head + rows], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `jatayu-events-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    pushToast({ title: 'Events exported', body: `${filtered.length} rows`, tone: 'success' });
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Event Log"
        description="Complete audit trail of hazard confirmations, exit crossings, unsafe movements and crowd surges."
        actions={
          <>
            <Button
              variant="ghost"
              size="sm"
              icon={<Download className="h-3.5 w-3.5" />}
              onClick={exportCsv}
            >
              Export CSV
            </Button>
            <Button
              variant="ghost"
              size="sm"
              icon={<Trash2 className="h-3.5 w-3.5" />}
              onClick={clearAcks}
            >
              Clear acks
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={<CheckCheck className="h-3.5 w-3.5" />}
              onClick={ackAll}
            >
              Acknowledge all
            </Button>
          </>
        }
      />

      {/* Priority tiles */}
      <div className="stagger grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {PRIORITIES.map((p) => {
          const n = p === 'ALL' ? events.length : (counts[p] ?? 0);
          const active = priority === p;
          return (
            <button
              key={p}
              onClick={() => setPriority(p)}
              className={clsx(
                'group rounded-xl border p-3 text-left transition-all duration-300 hover:-translate-y-0.5',
                active
                  ? 'border-brand-400/50 bg-brand-500/12 shadow-glow'
                  : 'border-white/[0.07] bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.05]',
              )}
            >
              <p className="text-[9px] font-bold uppercase tracking-[0.14em] text-slate-500">{p}</p>
              <p
                className={clsx(
                  'mt-1 font-mono text-2xl font-bold transition-colors',
                  p === 'CRITICAL'
                    ? 'text-red-400'
                    : p === 'HIGH'
                      ? 'text-orange-400'
                      : p === 'MEDIUM'
                        ? 'text-amber-400'
                        : p === 'LOW'
                          ? 'text-brand-300'
                          : 'text-white',
                )}
              >
                {n}
              </p>
            </button>
          );
        })}
      </div>

      {/* Filters + list */}
      <Panel className="overflow-hidden">
        <PanelHeader
          title="Filtered Stream"
          subtitle={`${filtered.length} of ${events.length} events`}
          icon={<BellRing className="h-4 w-4" />}
          actions={
            <Badge tone={onlyPending ? 'danger' : 'neutral'}>
              {onlyPending ? 'Pending only' : 'All events'}
            </Badge>
          }
        />

        <div className="flex flex-wrap items-center gap-2 border-b border-white/[0.07] p-3">
          <div className="relative min-w-[200px] flex-1">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
            <input
              className="field pl-9"
              placeholder="Search id, type, zone or message…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search events"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <Filter className="h-3.5 w-3.5 text-slate-500" />
            <select
              className="field w-auto pr-8 text-xs"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              aria-label="Filter by event type"
            >
              <option value="ALL">All types</option>
              {types.map((t) => (
                <option key={t} value={t}>
                  {t.replace(/_/g, ' ')}
                </option>
              ))}
            </select>
          </div>

          <Button
            variant={onlyPending ? 'danger' : 'ghost'}
            size="sm"
            onClick={() => setOnlyPending(!onlyPending)}
          >
            Unacknowledged
          </Button>
        </div>

        <div className="max-h-[calc(100vh-24rem)] min-h-[300px] divide-y divide-white/[0.045] overflow-y-auto">
          {filtered.length === 0 ? (
            <EmptyState
              icon={<BellRing className="h-6 w-6" />}
              title="No matching events"
              body="Adjust the filters, or wait for the backend to emit new events."
            />
          ) : (
            <AnimatePresence initial={false}>
              {filtered.map((e) => (
                <EventRow key={e.event_id} e={e} />
              ))}
            </AnimatePresence>
          )}
        </div>
      </Panel>
    </div>
  );
}
