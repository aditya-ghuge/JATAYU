import { Camera, Cpu, Play, Radio, Save, Video } from 'lucide-react';
import { useState } from 'react';
import { EventFeed } from '../components/dashboard/EventFeed';
import { HazardPanel } from '../components/dashboard/EvacuationPanel';
import { LiveFeed } from '../components/dashboard/LiveFeed';
import { PageHeader } from '../components/layout/PageHeader';
import { Button, SegmentedControl } from '../components/ui/Button';
import { Badge, Panel, PanelHeader } from '../components/ui/Primitives';
import { useStore } from '../lib/store';
import type { SourceType } from '../lib/types';

export default function LiveView() {
  const state = useStore((s) => s.state);
  const conn = useStore((s) => s.conn);
  const health = useStore((s) => s.health);
  const switchSource = useStore((s) => s.switchSource);

  const [sourceType, setSourceType] = useState<SourceType>(state?.source_type ?? 'webcam');
  const [sourcePath, setSourcePath] = useState('0');
  const [busy, setBusy] = useState(false);

  const apply = async () => {
    setBusy(true);
    await switchSource(sourceType, sourcePath);
    setBusy(false);
  };

  const placeholder =
    sourceType === 'webcam'
      ? '0  (device index)'
      : sourceType === 'file'
        ? 'samples/evacuation_drill.mp4'
        : 'rtsp://user:pass@192.168.1.64:554/Streaming/Channels/101';

  const specs = [
    { k: 'Camera ID', v: state?.camera_id ?? '—' },
    { k: 'Status', v: state?.camera_status ?? (conn.mode === 'LIVE' ? 'ONLINE' : 'SIMULATED') },
    { k: 'Source type', v: state?.source_type ?? sourceType },
    { k: 'Resolution', v: state?.frame_size ? `${state.frame_size[0]}×${state.frame_size[1]}` : '—' },
    { k: 'Frame rate', v: state?.fps ? `${state.fps.toFixed(1)} FPS` : '—' },
    { k: 'Detector', v: health?.detector ?? 'YOLOv8n · ByteTrack' },
    { k: 'Schema', v: state?.schema_version ?? '1.0' },
    { k: 'API latency', v: conn.latencyMs != null ? `${conn.latencyMs} ms` : '—' },
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Live Feed & Camera Control"
        description="Tactical MJPEG stream with AI overlays. Switch between webcam, video file and RTSP sources at runtime."
        actions={
          <Badge tone={conn.mode === 'LIVE' ? 'success' : 'warn'} dot>
            {conn.mode === 'LIVE' ? 'Streaming from backend' : 'Synthetic simulation'}
          </Badge>
        }
      />

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <LiveFeed />
        </div>

        <div className="space-y-4">
          {/* Source switcher */}
          <Panel>
            <PanelHeader
              title="Video Source"
              subtitle="POST /config · applies without restart"
              icon={<Video className="h-4 w-4" />}
            />
            <div className="space-y-3 p-4">
              <div>
                <span className="label">Input mode</span>
                <SegmentedControl<SourceType>
                  value={sourceType}
                  onChange={(v) => {
                    setSourceType(v);
                    setSourcePath(v === 'webcam' ? '0' : '');
                  }}
                  options={[
                    { value: 'webcam', label: 'Webcam', icon: <Camera className="h-3 w-3" /> },
                    { value: 'file', label: 'File', icon: <Play className="h-3 w-3" /> },
                    { value: 'rtsp', label: 'RTSP', icon: <Radio className="h-3 w-3" /> },
                  ]}
                  className="w-full"
                />
              </div>

              <div>
                <label className="label" htmlFor="source-path">
                  {sourceType === 'webcam'
                    ? 'Device index'
                    : sourceType === 'file'
                      ? 'File path'
                      : 'Stream URL'}
                </label>
                <input
                  id="source-path"
                  className="field font-mono text-xs"
                  value={sourcePath}
                  placeholder={placeholder}
                  onChange={(e) => setSourcePath(e.target.value)}
                />
              </div>

              <Button
                variant="primary"
                full
                loading={busy}
                onClick={() => void apply()}
                icon={<Save className="h-4 w-4" />}
              >
                Apply source
              </Button>

              {conn.mode === 'DEMO' && (
                <p className="rounded-lg border border-amber-400/20 bg-amber-500/[0.07] p-2.5 text-[11px] leading-snug text-amber-300/90">
                  Backend offline — start <code className="font-mono">python app/main.py</code> in the
                  <code className="font-mono"> cctv/</code> folder to control the real camera.
                </p>
              )}
            </div>
          </Panel>

          {/* Specs */}
          <Panel>
            <PanelHeader
              title="Pipeline Telemetry"
              subtitle="OpenCV → YOLO → Tracker → Zones"
              icon={<Cpu className="h-4 w-4" />}
            />
            <dl className="divide-y divide-white/[0.05]">
              {specs.map((s) => (
                <div
                  key={s.k}
                  className="flex items-center justify-between px-4 py-2 transition-colors hover:bg-white/[0.03]"
                >
                  <dt className="text-[11px] font-medium text-slate-500">{s.k}</dt>
                  <dd className="font-mono text-[11px] font-bold text-slate-200">{String(s.v)}</dd>
                </div>
              ))}
            </dl>
          </Panel>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <HazardPanel />
        <div className="min-h-[420px]">
          <EventFeed limit={16} />
        </div>
      </div>
    </div>
  );
}
