import { PopulationChart, ZoneBarChart } from '../components/dashboard/Charts';
import { EventFeed } from '../components/dashboard/EventFeed';
import { EvacuationPanel, HazardPanel } from '../components/dashboard/EvacuationPanel';
import { LiveFeed } from '../components/dashboard/LiveFeed';
import { StatCards } from '../components/dashboard/StatCards';
import { ZoneGrid } from '../components/dashboard/ZoneGrid';
import { PageHeader } from '../components/layout/PageHeader';

export default function Dashboard() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Command Center"
        description="Real-time disaster intelligence fused from CCTV vision, zone analytics and evacuation tracking."
      />

      <StatCards />

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <LiveFeed />
        </div>
        <div className="min-h-[420px]">
          <EventFeed limit={14} />
        </div>
      </div>

      <ZoneGrid />

      <div className="grid gap-4 lg:grid-cols-2">
        <EvacuationPanel />
        <HazardPanel />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <PopulationChart />
        <ZoneBarChart />
      </div>
    </div>
  );
}
