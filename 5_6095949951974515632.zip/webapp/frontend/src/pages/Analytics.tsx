import { Activity, Download, Gauge, TrendingUp } from 'lucide-react';
import {
  EventDonut,
  PopulationChart,
  RiskRadar,
  ZoneBarChart,
} from '../components/dashboard/Charts';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import {
  AnimatedNumber,
  Badge,
  Panel,
  PanelHeader,
  ProgressBar,
  RadialGauge,
} from '../components/ui/Primitives';
import { useStore } from '../lib/store';

export default function Analytics() {
  const state = useStore((s) => s.state);
  const history = useStore((s) => s.history);
  const events = useStore((s) => s.events);
  const pushToast = useStore((s) => s.pushToast);

  const zones = state?.population?.zones ?? [];
  const pop = state?.population;

  const peakVisible = history.reduce((a, s) => Math.max(a, s.visible), 0);
  const avgVisible =
    history.length > 0 ? history.reduce((a, s) => a + s.visible, 0) / history.length : 0;
  const avgOccupancy =
    zones.length > 0 ? zones.reduce((a, z) => a + z.occupancy_percent, 0) / zones.length : 0;
  const criticalEvents = events.filter((e) => String(e.priority).toUpperCase() === 'CRITICAL').length;

  const hazardZones = new Set((state?.hazards ?? []).map((h) => h.zone));
  const riskIndex = Math.min(
    100,
    Math.round(avgOccupancy * 0.45 + hazardZones.size * 22 + (pop?.entered ?? 0) * 6),
  );

  const exportReport = () => {
    const report = {
      generated_at: new Date().toISOString(),
      schema_version: state?.schema_version ?? '1.0',
      camera_id: state?.camera_id,
      summary: {
        peak_visible: peakVisible,
        average_visible: Math.round(avgVisible * 10) / 10,
        average_occupancy_percent: Math.round(avgOccupancy * 10) / 10,
        risk_index: riskIndex,
        critical_events: criticalEvents,
      },
      current_state: state,
      timeline: history,
      events,
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `jatayu-report-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    pushToast({ title: 'Report exported', body: a.download, tone: 'success' });
  };

  const kpis = [
    { label: 'Peak visible', value: peakVisible, sub: 'in this session' },
    { label: 'Avg visible', value: Math.round(avgVisible * 10) / 10, decimals: 1, sub: 'per sample' },
    { label: 'Avg occupancy', value: avgOccupancy, decimals: 1, suffix: '%', sub: 'across zones' },
    { label: 'Critical events', value: criticalEvents, sub: 'total recorded' },
    { label: 'Samples', value: history.length, sub: 'telemetry points' },
    { label: 'Hazard zones', value: hazardZones.size, sub: 'currently affected' },
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Analytics & Situation Report"
        description="Historical telemetry, zone risk profiling and exportable incident reports for the PS14 central system."
        actions={
          <Button
            variant="primary"
            size="sm"
            icon={<Download className="h-3.5 w-3.5" />}
            onClick={exportReport}
          >
            Export SITREP JSON
          </Button>
        }
      />

      {/* Risk header */}
      <Panel className="overflow-hidden">
        <div className="flex flex-col items-center gap-6 p-5 md:flex-row">
          <RadialGauge
            value={riskIndex}
            size={160}
            label="Risk index"
            sublabel={riskIndex > 65 ? 'ELEVATED' : riskIndex > 35 ? 'MODERATE' : 'LOW'}
            tone={riskIndex > 65 ? 'danger' : riskIndex > 35 ? 'warn' : 'safe'}
          />

          <div className="flex-1">
            <div className="mb-3 flex items-center gap-2">
              <Gauge className="h-4 w-4 text-brand-300" />
              <h3 className="text-sm font-bold text-white">Composite Risk Assessment</h3>
              <Badge tone={riskIndex > 65 ? 'danger' : riskIndex > 35 ? 'warn' : 'success'} dot>
                {riskIndex > 65 ? 'ELEVATED' : riskIndex > 35 ? 'MODERATE' : 'NOMINAL'}
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {kpis.map((k) => (
                <div
                  key={k.label}
                  className="group rounded-xl border border-white/[0.07] bg-white/[0.02] p-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-brand-400/30 hover:bg-white/[0.05]"
                >
                  <p className="text-[9px] font-bold uppercase tracking-[0.14em] text-slate-500">
                    {k.label}
                  </p>
                  <p className="mt-1 font-mono text-xl font-bold text-white">
                    <AnimatedNumber
                      value={k.value}
                      decimals={k.decimals ?? 0}
                      suffix={k.suffix ?? ''}
                    />
                  </p>
                  <p className="text-[10px] text-slate-600">{k.sub}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-2">
        <PopulationChart height={290} />
        <ZoneBarChart height={290} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <RiskRadar height={290} />
        <EventDonut height={290} />
      </div>

      {/* Zone breakdown table */}
      <Panel className="overflow-hidden">
        <PanelHeader
          title="Zone Breakdown"
          subtitle="Detailed per-zone occupancy and status"
          icon={<TrendingUp className="h-4 w-4" />}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-white/[0.07] bg-white/[0.02]">
              <tr className="text-[10px] uppercase tracking-widest text-slate-500">
                <th className="px-4 py-2.5 font-bold">Zone</th>
                <th className="px-4 py-2.5 font-bold">ID</th>
                <th className="px-4 py-2.5 font-bold">People</th>
                <th className="px-4 py-2.5 font-bold">Capacity</th>
                <th className="px-4 py-2.5 font-bold">Occupancy</th>
                <th className="px-4 py-2.5 font-bold">Level</th>
                <th className="px-4 py-2.5 font-bold">Hazard</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.045]">
              {zones.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                    Awaiting zone telemetry…
                  </td>
                </tr>
              ) : (
                zones.map((z) => (
                  <tr key={z.zone_id} className="transition-colors hover:bg-white/[0.03]">
                    <td className="px-4 py-2.5 font-semibold text-white">{z.name}</td>
                    <td className="px-4 py-2.5 font-mono text-[11px] text-slate-500">{z.zone_id}</td>
                    <td className="px-4 py-2.5 font-mono font-bold text-brand-300">{z.people}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-400">{z.capacity}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <ProgressBar
                          value={z.occupancy_percent}
                          tone={
                            z.occupancy_percent > 100
                              ? 'danger'
                              : z.occupancy_percent > 70
                                ? 'warn'
                                : 'safe'
                          }
                          height="h-1.5"
                          className="w-20"
                        />
                        <span className="font-mono text-[11px] text-slate-300">
                          {z.occupancy_percent.toFixed(0)}%
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <Badge
                        tone={
                          z.crowd_level === 'CRITICAL'
                            ? 'danger'
                            : z.crowd_level === 'HIGH'
                              ? 'warn'
                              : z.crowd_level === 'MODERATE'
                                ? 'warn'
                                : 'success'
                        }
                      >
                        {z.crowd_level}
                      </Badge>
                    </td>
                    <td className="px-4 py-2.5">
                      {hazardZones.has(z.zone_id) ? (
                        <Badge tone="danger" dot>
                          ACTIVE
                        </Badge>
                      ) : (
                        <span className="text-[11px] text-slate-600">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
