import clsx from 'clsx';
import {
  Ban,
  Copy,
  DoorOpen,
  Download,
  Map as MapIcon,
  MousePointerClick,
  Plus,
  Save,
  Trash2,
  Undo2,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { Button, IconButton, SegmentedControl } from '../components/ui/Button';
import { Badge, EmptyState, LevelBadge, Panel, PanelHeader, Switch } from '../components/ui/Primitives';
import { DEMO_FRAME } from '../lib/simulator';
import { useStore } from '../lib/store';
import type { ExitConfig, ZoneConfig } from '../lib/types';

type Mode = 'select' | 'zone' | 'exit';

export default function ZoneControl() {
  const zones = useStore((s) => s.zones);
  const exits = useStore((s) => s.exits);
  const state = useStore((s) => s.state);
  const saveZones = useStore((s) => s.saveZones);
  const saveExits = useStore((s) => s.saveExits);
  const pushToast = useStore((s) => s.pushToast);

  const W = state?.frame_size?.[0] ?? DEMO_FRAME.width;
  const H = state?.frame_size?.[1] ?? DEMO_FRAME.height;

  const [draftZones, setDraftZones] = useState<ZoneConfig[]>(zones);
  const [draftExits, setDraftExits] = useState<ExitConfig[]>(exits);
  const [mode, setMode] = useState<Mode>('select');
  const [points, setPoints] = useState<[number, number][]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [showLive, setShowLive] = useState(true);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => setDraftZones(zones), [zones]);
  useEffect(() => setDraftExits(exits), [exits]);

  const metrics = useMemo(
    () => new Map((state?.population?.zones ?? []).map((z) => [z.zone_id, z])),
    [state?.population?.zones],
  );
  const hazardZones = useMemo(
    () => new Set((state?.hazards ?? []).map((h) => h.zone)),
    [state?.hazards],
  );

  const toFrame = (e: React.MouseEvent<SVGSVGElement>): [number, number] => {
    const svg = svgRef.current!;
    const r = svg.getBoundingClientRect();
    return [
      Math.round(((e.clientX - r.left) / r.width) * W),
      Math.round(((e.clientY - r.top) / r.height) * H),
    ];
  };

  const onCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (mode === 'select') return;
    const p = toFrame(e);

    if (mode === 'exit') {
      const next = [...points, p];
      if (next.length === 2) {
        const id = `EXIT_${String.fromCharCode(65 + draftExits.length)}`;
        setDraftExits([
          ...draftExits,
          { exit_id: id, name: `Exit ${String.fromCharCode(65 + draftExits.length)}`, line: [next[0], next[1]] },
        ]);
        setPoints([]);
        setMode('select');
        pushToast({ title: 'Exit line added', body: id, tone: 'success' });
      } else {
        setPoints(next);
      }
      return;
    }

    setPoints([...points, p]);
  };

  const finishZone = () => {
    if (points.length < 3) {
      pushToast({ title: 'Need at least 3 points', tone: 'warn' });
      return;
    }
    const idx = draftZones.length;
    const id = `ZONE_${String.fromCharCode(65 + idx)}`;
    setDraftZones([
      ...draftZones,
      { zone_id: id, name: `Zone ${String.fromCharCode(65 + idx)}`, capacity: 12, polygon: points },
    ]);
    setPoints([]);
    setMode('select');
    setSelected(id);
    pushToast({ title: 'Zone created', body: `${id} · ${points.length} vertices`, tone: 'success' });
  };

  const updateZone = (id: string, patch: Partial<ZoneConfig>) =>
    setDraftZones(draftZones.map((z) => (z.zone_id === id ? { ...z, ...patch } : z)));

  const exportJson = (data: unknown, name: string) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    URL.revokeObjectURL(a.href);
    pushToast({ title: 'Exported', body: name, tone: 'success' });
  };

  const sel = draftZones.find((z) => z.zone_id === selected);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Zone & Exit Control"
        description="Draw polygon zones and virtual exit lines directly on the camera field of view. Exports the exact zones.json / exits.json format the backend consumes."
        actions={
          <>
            <Button
              variant="ghost"
              size="sm"
              icon={<Download className="h-3.5 w-3.5" />}
              onClick={() => exportJson(draftZones, 'zones.json')}
            >
              zones.json
            </Button>
            <Button
              variant="ghost"
              size="sm"
              icon={<Download className="h-3.5 w-3.5" />}
              onClick={() => exportJson(draftExits, 'exits.json')}
            >
              exits.json
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={<Save className="h-3.5 w-3.5" />}
              onClick={() => {
                void saveZones(draftZones);
                void saveExits(draftExits);
              }}
            >
              Sync to backend
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-3">
        {/* Canvas */}
        <Panel className="overflow-hidden xl:col-span-2">
          <PanelHeader
            title="Field of View Editor"
            subtitle={`${W}×${H} · ${draftZones.length} zones · ${draftExits.length} exits`}
            icon={<MapIcon className="h-4 w-4" />}
            actions={
              <>
                <Switch checked={showLive} onChange={setShowLive} label="Live people" />
                <SegmentedControl<Mode>
                  value={mode}
                  onChange={(m) => {
                    setMode(m);
                    setPoints([]);
                  }}
                  options={[
                    { value: 'select', label: 'Select', icon: <MousePointerClick className="h-3 w-3" /> },
                    { value: 'zone', label: 'Zone', icon: <Plus className="h-3 w-3" /> },
                    { value: 'exit', label: 'Exit', icon: <DoorOpen className="h-3 w-3" /> },
                  ]}
                />
              </>
            }
          />

          <div className="relative bg-ink-900 grid-lines">
            <svg
              ref={svgRef}
              viewBox={`0 0 ${W} ${H}`}
              onClick={onCanvasClick}
              className={clsx(
                'block w-full',
                mode === 'select' ? 'cursor-default' : 'cursor-crosshair',
              )}
              style={{ aspectRatio: `${W}/${H}` }}
            >
              {/* zones */}
              {draftZones.map((z) => {
                const m = metrics.get(z.zone_id);
                const hz = hazardZones.has(z.zone_id);
                const isSel = z.zone_id === selected;
                const stroke = hz
                  ? '#ef4444'
                  : m?.crowd_level === 'CRITICAL'
                    ? '#dc2626'
                    : m?.crowd_level === 'HIGH'
                      ? '#f97316'
                      : isSel
                        ? '#22d3ee'
                        : '#328bff';
                return (
                  <g
                    key={z.zone_id}
                    onClick={(e) => {
                      if (mode !== 'select') return;
                      e.stopPropagation();
                      setSelected(z.zone_id);
                    }}
                    className="cursor-pointer"
                  >
                    <polygon
                      points={z.polygon.map((p) => p.join(',')).join(' ')}
                      fill={stroke}
                      fillOpacity={isSel ? 0.24 : 0.11}
                      stroke={stroke}
                      strokeWidth={isSel ? 4 : 2.5}
                      strokeDasharray={hz ? '12 7' : undefined}
                      className="transition-all duration-300"
                    />
                    {z.polygon.map((p, i) => (
                      <circle
                        key={i}
                        cx={p[0]}
                        cy={p[1]}
                        r={isSel ? 6 : 4}
                        fill="#fff"
                        stroke={stroke}
                        strokeWidth={2}
                      />
                    ))}
                    <text
                      x={z.polygon[0][0] + 12}
                      y={z.polygon[0][1] + 26}
                      fill="#fff"
                      fontSize={16}
                      fontWeight={800}
                      fontFamily="ui-monospace, monospace"
                      style={{ paintOrder: 'stroke', stroke: '#040810', strokeWidth: 4 }}
                    >
                      {z.name} {m ? `· ${m.people}/${z.capacity}` : ''}
                    </text>
                  </g>
                );
              })}

              {/* exits */}
              {draftExits.map((ex) => (
                <g key={ex.exit_id}>
                  <line
                    x1={ex.line[0][0]}
                    y1={ex.line[0][1]}
                    x2={ex.line[1][0]}
                    y2={ex.line[1][1]}
                    stroke={ex.blocked ? '#ef4444' : '#22c55e'}
                    strokeWidth={6}
                    strokeDasharray="18 9"
                    strokeLinecap="round"
                  />
                  <text
                    x={(ex.line[0][0] + ex.line[1][0]) / 2}
                    y={(ex.line[0][1] + ex.line[1][1]) / 2 - 12}
                    fill={ex.blocked ? '#fca5a5' : '#86efac'}
                    fontSize={15}
                    fontWeight={800}
                    textAnchor="middle"
                    fontFamily="ui-monospace, monospace"
                    style={{ paintOrder: 'stroke', stroke: '#040810', strokeWidth: 4 }}
                  >
                    {ex.blocked ? '⛔' : '🚪'} {ex.name}
                  </text>
                </g>
              ))}

              {/* live people */}
              {showLive &&
                (state?.tracks ?? []).map((p) => {
                  const cx = (p.bbox[0] + p.bbox[2]) / 2;
                  const cy = (p.bbox[1] + p.bbox[3]) / 2;
                  return (
                    <circle
                      key={p.track_id}
                      cx={cx}
                      cy={cy}
                      r={7}
                      fill={hazardZones.has(p.current_zone ?? '') ? '#ef4444' : '#22d3ee'}
                      fillOpacity={0.9}
                      stroke="#04070d"
                      strokeWidth={2}
                    />
                  );
                })}

              {/* in-progress drawing */}
              {points.length > 0 && (
                <>
                  {mode === 'zone' && points.length > 1 && (
                    <polygon
                      points={points.map((p) => p.join(',')).join(' ')}
                      fill="#22d3ee"
                      fillOpacity={0.2}
                      stroke="#22d3ee"
                      strokeWidth={3}
                      strokeDasharray="8 5"
                    />
                  )}
                  {mode === 'exit' && points.length === 1 && (
                    <circle cx={points[0][0]} cy={points[0][1]} r={9} fill="#22c55e" />
                  )}
                  {points.map((p, i) => (
                    <circle key={i} cx={p[0]} cy={p[1]} r={7} fill="#22d3ee" stroke="#04070d" strokeWidth={2} />
                  ))}
                </>
              )}
            </svg>

            {mode !== 'select' && (
              <div className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded-xl border border-cyan-400/30 bg-ink-900/92 px-4 py-2 text-center backdrop-blur">
                <p className="text-[11px] font-bold uppercase tracking-widest text-cyan-300">
                  {mode === 'zone'
                    ? `Click to add vertices · ${points.length} placed`
                    : `Click 2 points for the exit line · ${points.length}/2`}
                </p>
              </div>
            )}
          </div>

          {mode === 'zone' && (
            <div className="flex items-center gap-2 border-t border-white/[0.07] p-3">
              <Button
                variant="success"
                size="sm"
                onClick={finishZone}
                disabled={points.length < 3}
                icon={<Save className="h-3.5 w-3.5" />}
              >
                Finish zone ({points.length} pts)
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setPoints(points.slice(0, -1))}
                disabled={points.length === 0}
                icon={<Undo2 className="h-3.5 w-3.5" />}
              >
                Undo point
              </Button>
              <Button variant="subtle" size="sm" onClick={() => { setPoints([]); setMode('select'); }}>
                Cancel
              </Button>
            </div>
          )}
        </Panel>

        {/* Side inspector */}
        <div className="space-y-4">
          <Panel>
            <PanelHeader
              title="Zones"
              subtitle={`${draftZones.length} configured`}
              icon={<MapIcon className="h-4 w-4" />}
            />
            <div className="max-h-72 divide-y divide-white/[0.05] overflow-y-auto">
              {draftZones.length === 0 ? (
                <EmptyState title="No zones" body="Switch to Zone mode and click to draw one." />
              ) : (
                draftZones.map((z) => {
                  const m = metrics.get(z.zone_id);
                  return (
                    <button
                      key={z.zone_id}
                      onClick={() => setSelected(z.zone_id)}
                      className={clsx(
                        'flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left transition-all hover:bg-white/[0.045]',
                        selected === z.zone_id && 'bg-brand-500/10',
                      )}
                    >
                      <span
                        className={clsx(
                          'h-8 w-1 rounded-full',
                          hazardZones.has(z.zone_id) ? 'bg-red-500' : 'bg-brand-500',
                        )}
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-xs font-bold text-white">{z.name}</span>
                        <span className="block font-mono text-[10px] text-slate-500">
                          {z.zone_id} · cap {z.capacity} · {z.polygon.length} pts
                        </span>
                      </span>
                      {m && <LevelBadge level={m.crowd_level} />}
                    </button>
                  );
                })
              )}
            </div>
          </Panel>

          {sel && (
            <Panel className="animate-slide-up">
              <PanelHeader
                title="Edit Zone"
                subtitle={sel.zone_id}
                icon={<MousePointerClick className="h-4 w-4" />}
                actions={
                  <IconButton
                    label="Delete zone"
                    variant="danger"
                    onClick={() => {
                      setDraftZones(draftZones.filter((z) => z.zone_id !== sel.zone_id));
                      setSelected(null);
                    }}
                    icon={<Trash2 className="h-3.5 w-3.5" />}
                  />
                }
              />
              <div className="space-y-3 p-4">
                <div>
                  <label className="label" htmlFor="z-name">Display name</label>
                  <input
                    id="z-name"
                    className="field"
                    value={sel.name}
                    onChange={(e) => updateZone(sel.zone_id, { name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="label" htmlFor="z-cap">
                    Capacity — {sel.capacity} people
                  </label>
                  <input
                    id="z-cap"
                    type="range"
                    min={1}
                    max={80}
                    value={sel.capacity}
                    onChange={(e) => updateZone(sel.zone_id, { capacity: Number(e.target.value) })}
                    className="h-2 w-full cursor-pointer appearance-none rounded-full bg-ink-600 accent-brand-500"
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2">
                  <span className="text-[11px] font-medium text-slate-400">
                    Mark as critical zone
                  </span>
                  <Switch
                    checked={!!sel.critical}
                    onChange={(v) => updateZone(sel.zone_id, { critical: v })}
                  />
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  full
                  icon={<Copy className="h-3.5 w-3.5" />}
                  onClick={() => {
                    void navigator.clipboard.writeText(JSON.stringify(sel, null, 2));
                    pushToast({ title: 'Zone JSON copied', tone: 'success' });
                  }}
                >
                  Copy zone JSON
                </Button>
              </div>
            </Panel>
          )}

          <Panel>
            <PanelHeader
              title="Exit Lines"
              subtitle={`${draftExits.length} virtual exits`}
              icon={<DoorOpen className="h-4 w-4" />}
            />
            <div className="divide-y divide-white/[0.05]">
              {draftExits.length === 0 ? (
                <EmptyState title="No exits" body="Switch to Exit mode and click 2 points." />
              ) : (
                draftExits.map((ex) => (
                  <div key={ex.exit_id} className="flex items-center gap-2 px-3.5 py-2.5">
                    <DoorOpen
                      className={clsx('h-4 w-4 shrink-0', ex.blocked ? 'text-red-400' : 'text-emerald-400')}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-bold text-white">{ex.name}</span>
                      <span className="block font-mono text-[10px] text-slate-500">
                        {ex.line[0].join(',')} → {ex.line[1].join(',')}
                      </span>
                    </span>
                    <IconButton
                      label={ex.blocked ? 'Mark clear' : 'Mark blocked'}
                      variant={ex.blocked ? 'danger' : 'ghost'}
                      onClick={() =>
                        setDraftExits(
                          draftExits.map((e) =>
                            e.exit_id === ex.exit_id ? { ...e, blocked: !e.blocked } : e,
                          ),
                        )
                      }
                      icon={<Ban className="h-3.5 w-3.5" />}
                    />
                    <IconButton
                      label="Delete exit"
                      variant="ghost"
                      onClick={() => setDraftExits(draftExits.filter((e) => e.exit_id !== ex.exit_id))}
                      icon={<Trash2 className="h-3.5 w-3.5" />}
                    />
                  </div>
                ))
              )}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
