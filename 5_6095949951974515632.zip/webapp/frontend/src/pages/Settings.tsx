import clsx from 'clsx';
import {
  Activity,
  CheckCircle2,
  Cloud,
  Gauge,
  Link2,
  Radio,
  RefreshCw,
  Server,
  Settings as Cog,
  Terminal,
  Volume2,
  XCircle,
  Zap,
} from 'lucide-react';
import { useState } from 'react';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Badge, Panel, PanelHeader, Switch } from '../components/ui/Primitives';
import { api, DEFAULT_API_BASE } from '../lib/api';
import { useStore } from '../lib/store';

const ENDPOINTS = [
  { method: 'GET', path: '/health', desc: 'Service liveness, FPS, detector info' },
  { method: 'GET', path: '/state', desc: 'Current population, zones, hazards, tracks' },
  { method: 'GET', path: '/events', desc: 'Rolling buffer of the last 100 events' },
  { method: 'GET', path: '/video_feed', desc: 'MJPEG annotated video stream' },
  { method: 'GET', path: '/zones', desc: 'Zone polygon configuration' },
  { method: 'GET', path: '/exits', desc: 'Virtual exit line configuration' },
  { method: 'POST', path: '/reset', desc: 'Reset evacuation counters' },
  { method: 'POST', path: '/config', desc: 'Switch video source at runtime' },
];

export default function Settings() {
  const apiBase = useStore((s) => s.apiBase);
  const setApiBaseUrl = useStore((s) => s.setApiBaseUrl);
  const pollMs = useStore((s) => s.pollMs);
  const setPollMs = useStore((s) => s.setPollMs);
  const soundOn = useStore((s) => s.soundOn);
  const toggleSound = useStore((s) => s.toggleSound);
  const conn = useStore((s) => s.conn);
  const health = useStore((s) => s.health);
  const forceDemo = useStore((s) => s.forceDemo);
  const pushToast = useStore((s) => s.pushToast);

  const [draft, setDraft] = useState(apiBase);
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<Record<string, 'ok' | 'fail' | 'pending'>>({});
  const [demo, setDemo] = useState(false);

  const runDiagnostics = async () => {
    setTesting(true);
    const next: Record<string, 'ok' | 'fail' | 'pending'> = {};
    const checks: [string, () => Promise<{ error: string | null }>][] = [
      ['/health', api.health],
      ['/state', api.state],
      ['/events', api.events],
      ['/zones', api.zones],
      ['/exits', api.exits],
    ];
    for (const [name, fn] of checks) {
      next[name] = 'pending';
      setResults({ ...next });
      const r = await fn();
      next[name] = r.error ? 'fail' : 'ok';
      setResults({ ...next });
    }
    setTesting(false);
    const okCount = Object.values(next).filter((v) => v === 'ok').length;
    pushToast({
      title: 'Diagnostics complete',
      body: `${okCount}/${checks.length} endpoints reachable`,
      tone: okCount === checks.length ? 'success' : okCount === 0 ? 'danger' : 'warn',
    });
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Settings & Diagnostics"
        description="Configure the backend connection, polling cadence, alert behaviour and run endpoint diagnostics."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Connection */}
        <Panel>
          <PanelHeader
            title="Backend Connection"
            subtitle="FastAPI service running the CCTV pipeline"
            icon={<Server className="h-4 w-4" />}
            actions={
              <Badge tone={conn.mode === 'LIVE' ? 'success' : 'warn'} dot>
                {conn.mode}
              </Badge>
            }
          />
          <div className="space-y-3 p-4">
            <div>
              <label className="label" htmlFor="api-base">
                API base URL
              </label>
              <div className="flex gap-2">
                <input
                  id="api-base"
                  className="field font-mono text-xs"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={DEFAULT_API_BASE}
                />
                <Button
                  variant="primary"
                  onClick={() => setApiBaseUrl(draft)}
                  icon={<Link2 className="h-4 w-4" />}
                >
                  Save
                </Button>
              </div>
              <p className="mt-1.5 text-[11px] text-slate-500">
                Default <code className="font-mono text-slate-400">{DEFAULT_API_BASE}</code> — change
                if the pipeline runs on another host.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { k: 'Status', v: conn.connected ? 'Connected' : 'Offline' },
                { k: 'Latency', v: conn.latencyMs != null ? `${conn.latencyMs} ms` : '—' },
                {
                  k: 'Last success',
                  v: conn.lastSuccess ? new Date(conn.lastSuccess).toLocaleTimeString() : 'never',
                },
                { k: 'Uptime', v: health?.uptime_seconds ? `${Math.round(health.uptime_seconds)}s` : '—' },
              ].map((x) => (
                <div key={x.k} className="rounded-lg border border-white/[0.07] bg-white/[0.02] p-2.5">
                  <p className="text-[9px] font-bold uppercase tracking-widest text-slate-500">
                    {x.k}
                  </p>
                  <p className="mt-0.5 font-mono text-xs font-bold text-slate-200">{x.v}</p>
                </div>
              ))}
            </div>

            {conn.error && (
              <p className="rounded-lg border border-red-400/25 bg-red-500/[0.07] p-2.5 font-mono text-[11px] text-red-300">
                {conn.error}
              </p>
            )}

            <Button
              variant="outline"
              full
              loading={testing}
              onClick={() => void runDiagnostics()}
              icon={<Activity className="h-4 w-4" />}
            >
              Run endpoint diagnostics
            </Button>

            {Object.keys(results).length > 0 && (
              <div className="space-y-1.5 rounded-lg border border-white/[0.07] bg-ink-900/60 p-3">
                {Object.entries(results).map(([k, v]) => (
                  <div key={k} className="flex items-center gap-2">
                    {v === 'ok' ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    ) : v === 'fail' ? (
                      <XCircle className="h-3.5 w-3.5 text-red-400" />
                    ) : (
                      <RefreshCw className="h-3.5 w-3.5 animate-spin text-slate-500" />
                    )}
                    <span className="font-mono text-[11px] text-slate-300">{k}</span>
                    <span
                      className={clsx(
                        'ml-auto font-mono text-[10px] font-bold uppercase',
                        v === 'ok' ? 'text-emerald-400' : v === 'fail' ? 'text-red-400' : 'text-slate-500',
                      )}
                    >
                      {v}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Panel>

        {/* Behaviour */}
        <Panel>
          <PanelHeader
            title="Interface Behaviour"
            subtitle="Polling, alerts and simulation"
            icon={<Cog className="h-4 w-4" />}
          />
          <div className="space-y-4 p-4">
            <div>
              <label className="label" htmlFor="poll">
                Poll interval — {pollMs} ms ({(1000 / pollMs).toFixed(1)} Hz)
              </label>
              <input
                id="poll"
                type="range"
                min={250}
                max={5000}
                step={250}
                value={pollMs}
                onChange={(e) => setPollMs(Number(e.target.value))}
                className="h-2 w-full cursor-pointer appearance-none rounded-full bg-ink-600 accent-brand-500"
              />
              <div className="mt-1 flex justify-between font-mono text-[10px] text-slate-600">
                <span>250ms · aggressive</span>
                <span>5000ms · relaxed</span>
              </div>
            </div>

            <div className="space-y-2.5">
              {[
                {
                  icon: Volume2,
                  title: 'Audible alerts',
                  body: 'Play a tone for CRITICAL and HIGH events',
                  checked: soundOn,
                  onChange: toggleSound,
                },
                {
                  icon: Zap,
                  title: 'Force demo simulation',
                  body: 'Ignore the live backend and run the built-in scenario engine',
                  checked: demo,
                  onChange: (v: boolean) => {
                    setDemo(v);
                    forceDemo(v);
                  },
                },
              ].map((row) => (
                <div
                  key={row.title}
                  className="flex items-start gap-3 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3 transition-colors hover:bg-white/[0.045]"
                >
                  <row.icon className="mt-0.5 h-4 w-4 shrink-0 text-brand-300" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-white">{row.title}</p>
                    <p className="mt-0.5 text-[11px] leading-snug text-slate-500">{row.body}</p>
                  </div>
                  <Switch checked={row.checked} onChange={row.onChange} />
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>

      {/* API reference */}
      <Panel className="overflow-hidden">
        <PanelHeader
          title="API Contract"
          subtitle="Endpoints this dashboard consumes"
          icon={<Cloud className="h-4 w-4" />}
        />
        <div className="divide-y divide-white/[0.045]">
          {ENDPOINTS.map((e) => (
            <div
              key={e.path + e.method}
              className="flex items-center gap-3 px-4 py-2.5 transition-colors hover:bg-white/[0.03]"
            >
              <span
                className={clsx(
                  'w-12 shrink-0 rounded-md px-1.5 py-0.5 text-center font-mono text-[10px] font-bold',
                  e.method === 'GET'
                    ? 'bg-emerald-500/14 text-emerald-300'
                    : 'bg-amber-500/14 text-amber-300',
                )}
              >
                {e.method}
              </span>
              <code className="shrink-0 font-mono text-xs font-bold text-brand-200">{e.path}</code>
              <span className="min-w-0 truncate text-[11px] text-slate-500">{e.desc}</span>
              <span
                className={clsx(
                  'ml-auto shrink-0 text-[10px] font-bold uppercase',
                  results[e.path] === 'ok'
                    ? 'text-emerald-400'
                    : results[e.path] === 'fail'
                      ? 'text-red-400'
                      : 'text-slate-600',
                )}
              >
                {results[e.path] ?? '—'}
              </span>
            </div>
          ))}
        </div>
      </Panel>

      {/* Quick start */}
      <Panel>
        <PanelHeader
          title="Start the Backend"
          subtitle="Run the CCTV vision pipeline to go LIVE"
          icon={<Terminal className="h-4 w-4" />}
        />
        <div className="p-4">
          <pre className="overflow-x-auto rounded-xl border border-white/[0.07] bg-ink-900/80 p-4 font-mono text-[11px] leading-relaxed text-slate-300">
{`# 1 — install dependencies
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 2 — run the pipeline + API (serves on :8000)
python app/main.py

# 3 — this dashboard auto-detects it within one poll cycle`}
          </pre>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge tone="info">
              <Gauge className="h-3 w-3" /> YOLOv8n
            </Badge>
            <Badge tone="info">
              <Radio className="h-3 w-3" /> ByteTrack
            </Badge>
            <Badge tone="info">
              <Server className="h-3 w-3" /> FastAPI + Uvicorn
            </Badge>
          </div>
        </div>
      </Panel>
    </div>
  );
}
