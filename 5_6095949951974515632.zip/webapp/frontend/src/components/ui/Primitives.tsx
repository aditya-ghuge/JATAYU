import clsx from 'clsx';
import React, { useEffect, useRef, useState } from 'react';
import type { CrowdLevel } from '../../lib/types';

/* ------------------------------------------------------------------ Panel */

export function Panel({
  className,
  children,
  hover = false,
  ...rest
}: React.HTMLAttributes<HTMLDivElement> & { hover?: boolean }) {
  return (
    <div {...rest} className={clsx('panel', hover && 'panel-hover', className)}>
      {children}
    </div>
  );
}

export function PanelHeader({
  title,
  subtitle,
  icon,
  actions,
  className,
}: {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={clsx(
        'flex items-center justify-between gap-3 border-b border-white/[0.07] px-4 py-3',
        className,
      )}
    >
      <div className="flex min-w-0 items-center gap-2.5">
        {icon && (
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-500/12 text-brand-300 ring-1 ring-brand-400/20">
            {icon}
          </span>
        )}
        <div className="min-w-0">
          <h3 className="truncate text-sm font-bold tracking-tight text-white">{title}</h3>
          {subtitle && <p className="truncate text-[11px] text-slate-500">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ Badges */

const levelStyles: Record<CrowdLevel, string> = {
  LOW: 'bg-emerald-500/14 text-emerald-300 ring-1 ring-emerald-400/25',
  MODERATE: 'bg-amber-500/14 text-amber-300 ring-1 ring-amber-400/25',
  HIGH: 'bg-orange-500/16 text-orange-300 ring-1 ring-orange-400/30',
  CRITICAL: 'bg-red-500/18 text-red-300 ring-1 ring-red-400/35',
};

export function LevelBadge({ level, className }: { level: CrowdLevel; className?: string }) {
  return (
    <span className={clsx('chip', levelStyles[level] ?? levelStyles.LOW, className)}>
      <span
        className={clsx(
          'h-1.5 w-1.5 rounded-full',
          level === 'LOW' && 'bg-emerald-400',
          level === 'MODERATE' && 'bg-amber-400',
          level === 'HIGH' && 'bg-orange-400',
          level === 'CRITICAL' && 'animate-blink bg-red-400',
        )}
      />
      {level}
    </span>
  );
}

const toneStyles = {
  info: 'bg-brand-500/14 text-brand-200 ring-1 ring-brand-400/25',
  success: 'bg-emerald-500/14 text-emerald-300 ring-1 ring-emerald-400/25',
  warn: 'bg-amber-500/14 text-amber-300 ring-1 ring-amber-400/25',
  danger: 'bg-red-500/16 text-red-300 ring-1 ring-red-400/30',
  neutral: 'bg-white/[0.06] text-slate-300 ring-1 ring-white/10',
} as const;

export function Badge({
  tone = 'neutral',
  children,
  className,
  dot = false,
}: {
  tone?: keyof typeof toneStyles;
  children: React.ReactNode;
  className?: string;
  dot?: boolean;
}) {
  return (
    <span className={clsx('chip', toneStyles[tone], className)}>
      {dot && <span className="h-1.5 w-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}

/* ------------------------------------------------- Animated number counter */

export function AnimatedNumber({
  value,
  decimals = 0,
  className,
  suffix = '',
}: {
  value: number;
  decimals?: number;
  className?: string;
  suffix?: string;
}) {
  const [display, setDisplay] = useState(value);
  const fromRef = useRef(value);
  const rafRef = useRef<number>();

  useEffect(() => {
    const from = fromRef.current;
    const to = value;
    if (from === to) return;
    const start = performance.now();
    const dur = 480;

    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (to - from) * eased);
      if (p < 1) rafRef.current = requestAnimationFrame(tick);
      else fromRef.current = to;
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [value]);

  return (
    <span className={clsx('tabular-nums', className)}>
      {display.toFixed(decimals)}
      {suffix}
    </span>
  );
}

/* ------------------------------------------------------------ Progress bar */

export function ProgressBar({
  value,
  tone = 'brand',
  height = 'h-2',
  showTrack = true,
  className,
}: {
  value: number;
  tone?: 'brand' | 'safe' | 'warn' | 'danger';
  height?: string;
  showTrack?: boolean;
  className?: string;
}) {
  const pct = Math.max(0, Math.min(100, value));
  const grad = {
    brand: 'from-brand-500 to-cyan-400',
    safe: 'from-emerald-500 to-emerald-300',
    warn: 'from-amber-500 to-amber-300',
    danger: 'from-red-600 to-orange-400',
  }[tone];

  return (
    <div
      className={clsx(
        'relative w-full overflow-hidden rounded-full',
        height,
        showTrack && 'bg-white/[0.07]',
        className,
      )}
    >
      <div
        className={clsx(
          'h-full rounded-full bg-gradient-to-r transition-[width] duration-700 ease-out',
          grad,
        )}
        style={{ width: `${pct}%` }}
      >
        <div className="h-full w-full animate-shimmer bg-gradient-to-r from-transparent via-white/35 to-transparent" />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------- Radial gauge */

export function RadialGauge({
  value,
  size = 132,
  stroke = 11,
  label,
  sublabel,
  tone = 'brand',
}: {
  value: number;
  size?: number;
  stroke?: number;
  label?: string;
  sublabel?: string;
  tone?: 'brand' | 'safe' | 'warn' | 'danger';
}) {
  const pct = Math.max(0, Math.min(100, value));
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  const colors = {
    brand: ['#328bff', '#22d3ee'],
    safe: ['#22c55e', '#86efac'],
    warn: ['#f59e0b', '#fcd34d'],
    danger: ['#dc2626', '#fb923c'],
  }[tone];

  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={`g-${tone}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={colors[0]} />
            <stop offset="100%" stopColor={colors[1]} />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,.07)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={`url(#g-${tone})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset .8s cubic-bezier(.16,1,.3,1)' }}
        />
      </svg>
      <div className="absolute inset-0 grid place-content-center text-center">
        <div className="font-mono text-2xl font-bold text-white">
          <AnimatedNumber value={pct} decimals={0} suffix="%" />
        </div>
        {label && (
          <div className="mt-0.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            {label}
          </div>
        )}
        {sublabel && <div className="text-[10px] text-slate-500">{sublabel}</div>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ Empty / Skel */

export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon?: React.ReactNode;
  title: string;
  body?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      {icon && (
        <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/[0.04] text-slate-500 ring-1 ring-white/10">
          {icon}
        </div>
      )}
      <div>
        <p className="text-sm font-semibold text-slate-300">{title}</p>
        {body && <p className="mt-1 max-w-sm text-xs text-slate-500">{body}</p>}
      </div>
      {action}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={clsx('relative overflow-hidden rounded-lg bg-white/[0.05]', className)}>
      <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </div>
  );
}

/* ------------------------------------------------------------------ Tooltip */

export function Tooltip({
  content,
  children,
  side = 'top',
}: {
  content: string;
  children: React.ReactNode;
  side?: 'top' | 'bottom';
}) {
  return (
    <span className="group/tt relative inline-flex">
      {children}
      <span
        className={clsx(
          'pointer-events-none absolute left-1/2 z-50 -translate-x-1/2 whitespace-nowrap rounded-lg border border-white/10 bg-ink-800 px-2 py-1 text-[11px] font-medium text-slate-200 opacity-0 shadow-xl transition-all duration-200 group-hover/tt:opacity-100',
          side === 'top'
            ? 'bottom-full mb-2 group-hover/tt:-translate-y-0.5'
            : 'top-full mt-2 group-hover/tt:translate-y-0.5',
        )}
      >
        {content}
      </span>
    </span>
  );
}

/* ------------------------------------------------------------------- Switch */

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="inline-flex items-center gap-2.5"
    >
      <span
        className={clsx(
          'relative h-5 w-9 rounded-full transition-all duration-300',
          checked ? 'bg-brand-500 shadow-[0_0_14px_-2px_rgba(50,139,255,.9)]' : 'bg-ink-600',
        )}
      >
        <span
          className={clsx(
            'absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all duration-300 ease-out',
            checked ? 'left-[1.15rem]' : 'left-0.5',
          )}
        />
      </span>
      {label && <span className="text-xs font-medium text-slate-300">{label}</span>}
    </button>
  );
}
