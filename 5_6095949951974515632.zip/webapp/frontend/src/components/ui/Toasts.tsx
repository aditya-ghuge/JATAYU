import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, CheckCircle2, Info, X, ShieldAlert } from 'lucide-react';
import { useStore } from '../../lib/store';

const toneMap = {
  info: {
    ring: 'ring-brand-400/30',
    bg: 'bg-brand-500/10',
    text: 'text-brand-200',
    Icon: Info,
  },
  success: {
    ring: 'ring-emerald-400/30',
    bg: 'bg-emerald-500/10',
    text: 'text-emerald-300',
    Icon: CheckCircle2,
  },
  warn: {
    ring: 'ring-amber-400/30',
    bg: 'bg-amber-500/10',
    text: 'text-amber-300',
    Icon: AlertTriangle,
  },
  danger: {
    ring: 'ring-red-400/40',
    bg: 'bg-red-500/12',
    text: 'text-red-300',
    Icon: ShieldAlert,
  },
} as const;

export function ToastHost() {
  const toasts = useStore((s) => s.toasts);
  const dismiss = useStore((s) => s.dismissToast);

  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[min(23rem,calc(100vw-2rem))] flex-col gap-2">
      <AnimatePresence initial={false}>
        {toasts.map((t) => {
          const cfg = toneMap[t.tone];
          return (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, x: 40, scale: 0.96 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 40, scale: 0.96 }}
              transition={{ type: 'spring', stiffness: 380, damping: 30 }}
              className={clsx(
                'pointer-events-auto flex items-start gap-3 rounded-xl border border-white/10 bg-ink-850/95 p-3 shadow-2xl ring-1 backdrop-blur-xl',
                cfg.ring,
              )}
            >
              <span className={clsx('grid h-8 w-8 shrink-0 place-items-center rounded-lg', cfg.bg, cfg.text)}>
                <cfg.Icon className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold uppercase tracking-wide text-white">{t.title}</p>
                {t.body && <p className="mt-0.5 break-words text-[11px] leading-snug text-slate-400">{t.body}</p>}
              </div>
              <button
                onClick={() => dismiss(t.id)}
                className="shrink-0 rounded-md p-1 text-slate-500 transition-colors hover:bg-white/5 hover:text-white"
                aria-label="Dismiss notification"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
