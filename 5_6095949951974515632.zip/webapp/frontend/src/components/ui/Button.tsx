import clsx from 'clsx';
import { Loader2 } from 'lucide-react';
import React, { useCallback, useRef, useState } from 'react';

type Variant = 'primary' | 'danger' | 'success' | 'ghost' | 'outline' | 'subtle';
type Size = 'sm' | 'md' | 'lg' | 'icon';

interface Ripple {
  id: number;
  x: number;
  y: number;
  size: number;
}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  pulse?: boolean;
  full?: boolean;
}

const variantClass: Record<Variant, string> = {
  primary: 'btn-primary',
  danger: 'btn-danger',
  success: 'btn-success',
  ghost: 'btn-ghost',
  outline: 'btn-outline',
  subtle: 'btn-subtle',
};

const sizeClass: Record<Size, string> = {
  sm: 'btn-sm',
  md: 'btn-md',
  lg: 'btn-lg',
  icon: 'btn-icon',
};

/**
 * Animated action button:
 *  - hover lift + glow + sheen sweep (CSS in index.css)
 *  - press scale-down
 *  - material-style click ripple
 *  - optional attention pulse ring
 */
export function Button({
  variant = 'ghost',
  size = 'md',
  loading = false,
  icon,
  iconRight,
  pulse = false,
  full = false,
  className,
  children,
  onClick,
  disabled,
  ...rest
}: ButtonProps) {
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const seq = useRef(0);

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      const el = e.currentTarget;
      const rect = el.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height) * 2.2;
      const id = seq.current++;
      setRipples((r) => [
        ...r,
        { id, x: e.clientX - rect.left - size / 2, y: e.clientY - rect.top - size / 2, size },
      ]);
      window.setTimeout(() => setRipples((r) => r.filter((x) => x.id !== id)), 620);
      onClick?.(e);
    },
    [onClick],
  );

  return (
    <button
      {...rest}
      onClick={handleClick}
      disabled={disabled || loading}
      className={clsx(
        'btn',
        variantClass[variant],
        sizeClass[size],
        full && 'w-full',
        pulse && 'ring-2 ring-red-500/50',
        className,
      )}
    >
      {pulse && (
        <span className="pointer-events-none absolute inset-0 animate-pulse-ring rounded-xl bg-red-500/35" />
      )}

      {ripples.map((r) => (
        <span
          key={r.id}
          className="pointer-events-none absolute rounded-full bg-white/30"
          style={{
            left: r.x,
            top: r.y,
            width: r.size,
            height: r.size,
            animation: 'ripple .6s cubic-bezier(.22,1,.36,1) forwards',
          }}
        />
      ))}

      <span className="relative z-10 inline-flex items-center gap-2">
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          icon && <span className="transition-transform duration-200 group-hover:scale-110">{icon}</span>
        )}
        {children}
        {iconRight}
      </span>

      <style>{`@keyframes ripple{from{transform:scale(0);opacity:.55}to{transform:scale(1);opacity:0}}`}</style>
    </button>
  );
}

/** Small icon-only button used in toolbars. */
export function IconButton({
  label,
  className,
  ...props
}: ButtonProps & { label: string }) {
  return (
    <Button
      {...props}
      size="icon"
      aria-label={label}
      title={label}
      className={clsx('rounded-lg', className)}
    />
  );
}

/** Segmented toggle used for tabs / mode switches. */
export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: { value: T; label: string; icon?: React.ReactNode }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div
      className={clsx(
        'inline-flex rounded-xl border border-white/10 bg-ink-800/70 p-1',
        className,
      )}
      role="tablist"
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.value)}
            className={clsx(
              'relative inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all duration-250',
              active
                ? 'bg-gradient-to-b from-brand-500 to-brand-700 text-white shadow-[0_4px_14px_-4px_rgba(27,108,245,.8)]'
                : 'text-slate-400 hover:bg-white/5 hover:text-slate-100',
            )}
          >
            {o.icon}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
