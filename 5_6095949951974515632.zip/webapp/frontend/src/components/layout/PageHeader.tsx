import type { ReactNode } from 'react';

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 pb-1">
      <div className="min-w-0 animate-slide-up">
        <h1 className="text-2xl font-black tracking-tight text-gradient sm:text-[1.7rem]">
          {title}
        </h1>
        {description && (
          <p className="mt-1 max-w-3xl text-xs leading-relaxed text-slate-500 sm:text-[13px]">
            {description}
          </p>
        )}
        <div className="mt-3 h-[2px] w-28 rounded-full divide-glow" />
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
