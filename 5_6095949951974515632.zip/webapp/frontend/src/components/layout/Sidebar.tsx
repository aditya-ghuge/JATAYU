import clsx from 'clsx';
import { motion } from 'framer-motion';
import {
  Activity,
  BarChart3,
  Bell,
  ChevronLeft,
  LayoutDashboard,
  Map,
  Settings,
  Video,
  X,
} from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useStore } from '../../lib/store';

const nav = [
  { to: '/', label: 'Command Center', icon: LayoutDashboard, end: true },
  { to: '/live', label: 'Live Feed', icon: Video },
  { to: '/zones', label: 'Zone Control', icon: Map },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/events', label: 'Event Log', icon: Bell, badge: true },
  { to: '/settings', label: 'Settings', icon: Settings },
];

export function Sidebar({
  collapsed,
  onToggle,
  mobileOpen,
  onCloseMobile,
}: {
  collapsed: boolean;
  onToggle: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const events = useStore((s) => s.events);
  const acked = useStore((s) => s.acked);
  const conn = useStore((s) => s.conn);

  const unacked = events.filter(
    (e) => !acked.has(e.event_id) && ['CRITICAL', 'HIGH'].includes(String(e.priority).toUpperCase()),
  ).length;

  const body = (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className="flex h-16 items-center gap-3 border-b border-white/[0.07] px-4">
        <div className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-800 shadow-[0_6px_20px_-6px_rgba(27,108,245,.9)]">
          <Activity className="h-5 w-5 text-white" />
          <span className="absolute inset-0 animate-pulse-ring rounded-xl bg-brand-400/40" />
        </div>
        {!collapsed && (
          <div className="min-w-0 overflow-hidden">
            <p className="truncate text-base font-black tracking-tight text-white">JATAYU</p>
            <p className="truncate text-[10px] font-semibold uppercase tracking-[0.18em] text-brand-300/80">
              PS14 · Disaster Intel
            </p>
          </div>
        )}
        <button
          onClick={onCloseMobile}
          className="ml-auto rounded-lg p-1.5 text-slate-400 hover:bg-white/5 hover:text-white lg:hidden"
          aria-label="Close menu"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-1 overflow-y-auto p-3 no-scrollbar">
        {nav.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onCloseMobile}
            className={({ isActive }) =>
              clsx(
                'group relative flex items-center gap-3 overflow-hidden rounded-xl px-3 py-2.5 text-sm font-semibold transition-all duration-250',
                isActive
                  ? 'bg-gradient-to-r from-brand-500/22 to-transparent text-white'
                  : 'text-slate-400 hover:translate-x-0.5 hover:bg-white/[0.05] hover:text-white',
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <motion.span
                    layoutId="nav-indicator"
                    className="absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-r-full bg-gradient-to-b from-brand-300 to-cyan-400 shadow-[0_0_12px_rgba(50,139,255,.9)]"
                    transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                  />
                )}
                <item.icon
                  className={clsx(
                    'h-[18px] w-[18px] shrink-0 transition-transform duration-250 group-hover:scale-110',
                    isActive && 'text-brand-300',
                  )}
                />
                {!collapsed && <span className="truncate">{item.label}</span>}
                {!collapsed && item.badge && unacked > 0 && (
                  <span className="ml-auto grid h-5 min-w-5 place-items-center rounded-full bg-red-500 px-1.5 text-[10px] font-black text-white shadow-[0_0_12px_rgba(239,68,68,.85)]">
                    {unacked > 99 ? '99+' : unacked}
                  </span>
                )}
                {collapsed && item.badge && unacked > 0 && (
                  <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,.9)]" />
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Status footer */}
      <div className="border-t border-white/[0.07] p-3">
        <div
          className={clsx(
            'rounded-xl border p-3 transition-colors',
            conn.mode === 'LIVE'
              ? 'border-emerald-400/25 bg-emerald-500/[0.07]'
              : 'border-amber-400/25 bg-amber-500/[0.07]',
          )}
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span
                className={clsx(
                  'absolute inline-flex h-full w-full animate-ping rounded-full opacity-75',
                  conn.mode === 'LIVE' ? 'bg-emerald-400' : 'bg-amber-400',
                )}
              />
              <span
                className={clsx(
                  'relative inline-flex h-2 w-2 rounded-full',
                  conn.mode === 'LIVE' ? 'bg-emerald-500' : 'bg-amber-500',
                )}
              />
            </span>
            {!collapsed && (
              <span
                className={clsx(
                  'text-[10px] font-black uppercase tracking-widest',
                  conn.mode === 'LIVE' ? 'text-emerald-300' : 'text-amber-300',
                )}
              >
                {conn.mode === 'LIVE' ? 'Live Backend' : 'Demo Simulation'}
              </span>
            )}
          </div>
          {!collapsed && (
            <p className="mt-1.5 font-mono text-[10px] leading-tight text-slate-500">
              {conn.mode === 'LIVE'
                ? `latency ${conn.latencyMs ?? '–'} ms`
                : 'python app/main.py to go live'}
            </p>
          )}
        </div>

        <button
          onClick={onToggle}
          className="mt-2 hidden w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-2 text-[11px] font-semibold text-slate-400 transition-all hover:bg-white/[0.07] hover:text-white lg:flex"
        >
          <ChevronLeft
            className={clsx('h-3.5 w-3.5 transition-transform duration-300', collapsed && 'rotate-180')}
          />
          {!collapsed && 'Collapse'}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <aside
        className={clsx(
          'fixed left-0 top-0 z-40 hidden h-screen border-r border-white/[0.07] bg-ink-850/80 backdrop-blur-xl transition-[width] duration-300 ease-out lg:block',
          collapsed ? 'w-[76px]' : 'w-[248px]',
        )}
      >
        {body}
      </aside>

      {/* Mobile */}
      <div
        className={clsx(
          'fixed inset-0 z-50 lg:hidden',
          mobileOpen ? 'pointer-events-auto' : 'pointer-events-none',
        )}
      >
        <div
          onClick={onCloseMobile}
          className={clsx(
            'absolute inset-0 bg-black/65 backdrop-blur-sm transition-opacity duration-300',
            mobileOpen ? 'opacity-100' : 'opacity-0',
          )}
        />
        <aside
          className={clsx(
            'absolute left-0 top-0 h-full w-[270px] border-r border-white/10 bg-ink-850 transition-transform duration-300 ease-out',
            mobileOpen ? 'translate-x-0' : '-translate-x-full',
          )}
        >
          {body}
        </aside>
      </div>
    </>
  );
}
