import clsx from 'clsx';
import {
  FlameKindling,
  Gauge,
  Menu,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useStore } from '../../lib/store';
import { Button, IconButton } from '../ui/Button';
import { Badge, Tooltip } from '../ui/Primitives';

export function Topbar({ onOpenMenu }: { onOpenMenu: () => void }) {
  const conn = useStore((s) => s.conn);
  const state = useStore((s) => s.state);
  const paused = useStore((s) => s.paused);
  const soundOn = useStore((s) => s.soundOn);
  const togglePause = useStore((s) => s.togglePause);
  const toggleSound = useStore((s) => s.toggleSound);
  const resetCounters = useStore((s) => s.resetCounters);

  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const confirmed = (state?.hazards ?? []).filter((h) => h.status !== 'DETECTING');
  const critical = confirmed.length > 0;

  return (
    <header
      className={clsx(
        'sticky top-0 z-30 border-b backdrop-blur-xl transition-colors duration-500',
        critical
          ? 'border-red-500/30 bg-red-950/25'
          : 'border-white/[0.07] bg-ink-900/80',
      )}
    >
      {critical && (
        <div className="h-[2px] w-full animate-blink bg-gradient-to-r from-transparent via-red-500 to-transparent" />
      )}

      <div className="flex h-16 items-center gap-3 px-4">
        <IconButton
          label="Open menu"
          variant="ghost"
          onClick={onOpenMenu}
          className="lg:hidden"
          icon={<Menu className="h-4 w-4" />}
        />

        {/* Threat level */}
        <div className="flex min-w-0 items-center gap-3">
          <div
            className={clsx(
              'flex items-center gap-2 rounded-xl border px-3 py-1.5 transition-all duration-500',
              critical
                ? 'border-red-400/40 bg-red-500/12 shadow-[0_0_22px_-8px_rgba(239,68,68,.9)]'
                : 'border-emerald-400/25 bg-emerald-500/10',
            )}
          >
            {critical ? (
              <FlameKindling className="h-4 w-4 animate-blink text-red-400" />
            ) : (
              <Gauge className="h-4 w-4 text-emerald-400" />
            )}
            <div className="leading-none">
              <p className="text-[9px] font-bold uppercase tracking-[0.16em] text-slate-400">
                Threat Level
              </p>
              <p
                className={clsx(
                  'mt-0.5 text-xs font-black uppercase tracking-wide',
                  critical ? 'text-red-300' : 'text-emerald-300',
                )}
              >
                {critical ? `Critical · ${confirmed.length} hazard${confirmed.length > 1 ? 's' : ''}` : 'Nominal'}
              </p>
            </div>
          </div>

          <div className="hidden items-center gap-2 md:flex">
            <Badge tone={conn.mode === 'LIVE' ? 'success' : 'warn'} dot>
              {conn.mode}
            </Badge>
            {state?.fps != null && (
              <Badge tone="info">{state.fps.toFixed(1)} FPS</Badge>
            )}
            {state?.camera_id && <Badge tone="neutral">{state.camera_id}</Badge>}
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <div className="mr-1 hidden text-right sm:block">
            <p className="font-mono text-sm font-bold leading-none text-white">
              {now.toLocaleTimeString([], { hour12: false })}
            </p>
            <p className="mt-0.5 text-[10px] text-slate-500">
              {now.toLocaleDateString([], { day: '2-digit', month: 'short', year: 'numeric' })}
            </p>
          </div>

          <Tooltip content={conn.mode === 'LIVE' ? `Connected · ${conn.latencyMs}ms` : 'Backend offline'}>
            <span
              className={clsx(
                'grid h-9 w-9 place-items-center rounded-lg border',
                conn.mode === 'LIVE'
                  ? 'border-emerald-400/25 bg-emerald-500/10 text-emerald-400'
                  : 'border-amber-400/25 bg-amber-500/10 text-amber-400',
              )}
            >
              {conn.mode === 'LIVE' ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
            </span>
          </Tooltip>

          <IconButton
            label={soundOn ? 'Mute alerts' : 'Unmute alerts'}
            variant="ghost"
            onClick={toggleSound}
            icon={soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          />

          <IconButton
            label="Reset evacuation counters"
            variant="ghost"
            onClick={() => void resetCounters()}
            icon={<RotateCcw className="h-4 w-4" />}
          />

          <Button
            variant={paused ? 'success' : 'outline'}
            size="sm"
            onClick={togglePause}
            icon={paused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
          >
            <span className="hidden sm:inline">{paused ? 'Resume' : 'Pause'}</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
