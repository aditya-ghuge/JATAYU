import clsx from 'clsx';
import { motion } from 'framer-motion';
import { Flame, Grid3x3, ShieldAlert, Users, Wind } from 'lucide-react';
import { useMemo } from 'react';
import { useStore } from '../../lib/store';
import type { CrowdLevel } from '../../lib/types';
import {
  AnimatedNumber,
  Badge,
  EmptyState,
  LevelBadge,
  Panel,
  PanelHeader,
  ProgressBar,
} from '../ui/Primitives';

const levelTone: Record<CrowdLevel, 'safe' | 'warn' | 'danger' | 'brand'> = {
  LOW: 'safe',
  MODERATE: 'warn',
  HIGH: 'warn',
  CRITICAL: 'danger',
};

export function ZoneGrid() {
  const state = useStore((s) => s.state);
  const zones = state?.population?.zones ?? [];

  const hazardsByZone = useMemo(() => {
    const map = new Map<string, { type: string; status?: string; confidence: number }[]>();
    for (const h of state?.hazards ?? []) {
      const arr = map.get(h.zone) ?? [];
      arr.push({ type: String(h.type), status: h.status, confidence: h.confidence });
      map.set(h.zone, arr);
    }
    return map;
  }, [state?.hazards]);

  return (
    <Panel>
      <PanelHeader
        title="Zone Occupancy Matrix"
        subtitle={`${zones.length} monitored zones · thresholds LOW ≤40% · MOD ≤70% · HIGH ≤100%`}
        icon={<Grid3x3 className="h-4 w-4" />}
        actions={
          <Badge tone="info">
            <Users className="h-3 w-3" />
            {zones.reduce((a, z) => a + z.people, 0)} in zones
          </Badge>
        }
      />

      {zones.length === 0 ? (
        <EmptyState
          icon={<Grid3x3 className="h-6 w-6" />}
          title="No zone telemetry"
          body="Waiting for the first /state payload from the CCTV backend."
        />
      ) : (
        <div className="grid gap-3 p-4 sm:grid-cols-2 xl:grid-cols-4">
          {zones.map((z, i) => {
            const hz = hazardsByZone.get(z.zone_id) ?? [];
            const confirmed = hz.filter((h) => h.status !== 'DETECTING');
            const danger = confirmed.length > 0;
            const tone = danger ? 'danger' : levelTone[z.crowd_level];

            return (
              <motion.div
                key={z.zone_id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, type: 'spring', stiffness: 260, damping: 26 }}
                className={clsx(
                  'group relative overflow-hidden rounded-xl border p-3.5 transition-all duration-300 hover:-translate-y-1',
                  danger
                    ? 'border-red-400/40 bg-red-500/[0.07] hover:shadow-[0_18px_40px_-20px_rgba(239,68,68,.95)]'
                    : z.crowd_level === 'CRITICAL'
                      ? 'border-red-400/30 bg-red-500/[0.05]'
                      : z.crowd_level === 'HIGH'
                        ? 'border-orange-400/25 bg-orange-500/[0.05]'
                        : 'border-white/[0.08] bg-white/[0.02] hover:border-brand-400/35 hover:shadow-glow',
                )}
              >
                {danger && (
                  <span className="absolute inset-0 animate-blink bg-red-500/[0.06]" />
                )}

                <div className="relative flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-white">{z.name}</p>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-slate-500">
                      {z.zone_id}
                    </p>
                  </div>
                  <LevelBadge level={z.crowd_level} />
                </div>

                <div className="relative mt-3 flex items-end justify-between">
                  <div className="flex items-baseline gap-1">
                    <AnimatedNumber
                      value={z.people}
                      className="font-mono text-2xl font-bold text-white"
                    />
                    <span className="font-mono text-xs text-slate-500">/ {z.capacity}</span>
                  </div>
                  <span
                    className={clsx(
                      'font-mono text-sm font-bold',
                      z.occupancy_percent > 100
                        ? 'text-red-400'
                        : z.occupancy_percent > 70
                          ? 'text-orange-400'
                          : z.occupancy_percent > 40
                            ? 'text-amber-400'
                            : 'text-emerald-400',
                    )}
                  >
                    <AnimatedNumber value={z.occupancy_percent} decimals={0} suffix="%" />
                  </span>
                </div>

                <ProgressBar
                  value={z.occupancy_percent}
                  tone={tone}
                  className="relative mt-2.5"
                  height="h-1.5"
                />

                {hz.length > 0 && (
                  <div className="relative mt-3 flex flex-wrap gap-1.5 border-t border-white/[0.07] pt-2.5">
                    {hz.map((h, idx) => (
                      <span
                        key={idx}
                        className={clsx(
                          'chip',
                          h.status === 'DETECTING'
                            ? 'bg-amber-500/14 text-amber-300 ring-1 ring-amber-400/25'
                            : 'bg-red-500/16 text-red-300 ring-1 ring-red-400/35',
                        )}
                      >
                        {h.type === 'FIRE' ? (
                          <Flame className="h-3 w-3" />
                        ) : h.type === 'SMOKE' ? (
                          <Wind className="h-3 w-3" />
                        ) : (
                          <ShieldAlert className="h-3 w-3" />
                        )}
                        {h.type} {(h.confidence * 100).toFixed(0)}%
                        {h.status === 'DETECTING' && ' …'}
                      </span>
                    ))}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </Panel>
  );
}
