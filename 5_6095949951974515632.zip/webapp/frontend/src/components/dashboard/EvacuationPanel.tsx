import clsx from 'clsx';
import {
  DoorOpen,
  Flame,
  LogIn,
  ShieldCheck,
  Siren,
  Users,
  Wind,
  Zap,
} from 'lucide-react';
import { useStore } from '../../lib/store';
import { Button } from '../ui/Button';
import {
  AnimatedNumber,
  Badge,
  EmptyState,
  Panel,
  PanelHeader,
  ProgressBar,
  RadialGauge,
} from '../ui/Primitives';

export function EvacuationPanel() {
  const state = useStore((s) => s.state);
  const pop = state?.population;

  const visible = pop?.total_visible ?? 0;
  const evacuated = pop?.evacuated ?? 0;
  const entered = pop?.entered ?? 0;
  const initial = pop?.initial_population ?? Math.max(visible + evacuated, 1);
  const pct = pop?.evacuation_percentage ?? (evacuated / Math.max(initial, 1)) * 100;
  const remaining = pop?.remaining ?? Math.max(0, initial - evacuated);

  const tone = pct >= 80 ? 'safe' : pct >= 40 ? 'warn' : 'danger';

  const rows = [
    { label: 'Initial population', value: initial, icon: Users, color: 'text-brand-300' },
    { label: 'Currently visible', value: visible, icon: Users, color: 'text-cyan-400' },
    { label: 'Evacuated (outbound)', value: evacuated, icon: DoorOpen, color: 'text-emerald-400' },
    { label: 'Remaining inside', value: remaining, icon: ShieldCheck, color: 'text-amber-400' },
    { label: 'Unsafe entries (inbound)', value: entered, icon: LogIn, color: 'text-red-400' },
    {
      label: 'Potentially unaccounted',
      value: pop?.potentially_unaccounted ?? Math.max(0, initial - evacuated - visible),
      icon: Siren,
      color: 'text-orange-400',
    },
  ];

  return (
    <Panel>
      <PanelHeader
        title="Evacuation Monitor"
        subtitle="Exit-line crossing · deduplicated by track ID"
        icon={<DoorOpen className="h-4 w-4" />}
        actions={
          <Badge tone={tone === 'safe' ? 'success' : tone === 'warn' ? 'warn' : 'danger'} dot>
            {pct >= 80 ? 'On track' : pct >= 40 ? 'In progress' : 'Early stage'}
          </Badge>
        }
      />

      <div className="flex flex-col items-center gap-5 p-5 sm:flex-row">
        <div className="shrink-0">
          <RadialGauge
            value={pct}
            label="Evacuated"
            sublabel={`${evacuated} / ${initial}`}
            tone={tone}
            size={148}
          />
        </div>

        <div className="w-full space-y-2">
          {rows.map((r) => (
            <div
              key={r.label}
              className="group flex items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-white/[0.04]"
            >
              <r.icon className={clsx('h-4 w-4 shrink-0 transition-transform group-hover:scale-110', r.color)} />
              <span className="min-w-0 flex-1 truncate text-[11px] font-medium text-slate-400">
                {r.label}
              </span>
              <AnimatedNumber
                value={r.value}
                className="font-mono text-sm font-bold text-white"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="border-t border-white/[0.07] px-5 py-3">
        <div className="mb-1.5 flex items-center justify-between text-[10px] font-bold uppercase tracking-widest">
          <span className="text-slate-500">Evacuation progress</span>
          <span className="font-mono text-slate-300">{pct.toFixed(1)}%</span>
        </div>
        <ProgressBar value={pct} tone={tone} height="h-2.5" />
      </div>
    </Panel>
  );
}

/** Hazard board + simulation controls. */
export function HazardPanel() {
  const state = useStore((s) => s.state);
  const zones = useStore((s) => s.zones);
  const mode = useStore((s) => s.conn.mode);
  const injectHazard = useStore((s) => s.injectHazard);
  const clearHazards = useStore((s) => s.clearHazards);
  const triggerSurge = useStore((s) => s.triggerSurge);

  const hazards = state?.hazards ?? [];
  const confirmed = hazards.filter((h) => h.status !== 'DETECTING');

  return (
    <Panel className="flex h-full flex-col">
      <PanelHeader
        title="Hazard Board"
        subtitle="Temporal confirmation · 15 frames to confirm"
        icon={<Flame className="h-4 w-4" />}
        actions={
          <Badge tone={confirmed.length > 0 ? 'danger' : 'success'} dot>
            {confirmed.length > 0 ? `${confirmed.length} confirmed` : 'All clear'}
          </Badge>
        }
      />

      <div className="flex-1 space-y-2 p-4">
        {hazards.length === 0 ? (
          <EmptyState
            icon={<ShieldCheck className="h-6 w-6" />}
            title="No hazards detected"
            body="Fire, smoke and debris detections appear here once the vision engine reports them."
          />
        ) : (
          hazards.map((h, i) => {
            const isFire = String(h.type).toUpperCase() === 'FIRE';
            const isSmoke = String(h.type).toUpperCase() === 'SMOKE';
            const confirmedNow = h.status !== 'DETECTING';
            const zoneName = zones.find((z) => z.zone_id === h.zone)?.name ?? h.zone;
            const progress = Math.min(100, ((h.frames_detected ?? 15) / 15) * 100);

            return (
              <div
                key={`${h.type}-${h.zone}-${i}`}
                className={clsx(
                  'relative overflow-hidden rounded-xl border p-3 transition-all duration-300 hover:-translate-y-0.5',
                  confirmedNow
                    ? 'border-red-400/40 bg-red-500/[0.08] shadow-[0_10px_30px_-16px_rgba(239,68,68,.9)]'
                    : 'border-amber-400/30 bg-amber-500/[0.05]',
                )}
              >
                {confirmedNow && <span className="absolute inset-0 animate-blink bg-red-500/[0.05]" />}

                <div className="relative flex items-center gap-3">
                  <span
                    className={clsx(
                      'grid h-10 w-10 shrink-0 place-items-center rounded-lg',
                      confirmedNow ? 'bg-red-500/18 text-red-300' : 'bg-amber-500/16 text-amber-300',
                    )}
                  >
                    {isFire ? (
                      <Flame className={clsx('h-5 w-5', confirmedNow && 'animate-blink')} />
                    ) : isSmoke ? (
                      <Wind className="h-5 w-5" />
                    ) : (
                      <Siren className="h-5 w-5" />
                    )}
                  </span>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-black uppercase tracking-wide text-white">
                        {h.type}
                      </p>
                      <Badge tone={confirmedNow ? 'danger' : 'warn'}>
                        {h.status ?? 'CONFIRMED'}
                      </Badge>
                    </div>
                    <p className="truncate text-[11px] text-slate-400">
                      {zoneName} · {(h.confidence * 100).toFixed(1)}% confidence
                    </p>
                  </div>
                </div>

                {!confirmedNow && (
                  <div className="relative mt-2.5">
                    <div className="mb-1 flex justify-between font-mono text-[9px] uppercase tracking-widest text-slate-500">
                      <span>Temporal confirmation</span>
                      <span>{h.frames_detected ?? 0}/15 frames</span>
                    </div>
                    <ProgressBar value={progress} tone="warn" height="h-1" />
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {mode === 'DEMO' && (
        <div className="border-t border-white/[0.07] p-3">
          <p className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-500">
            <Zap className="h-3 w-3" /> Simulation controls
          </p>
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant="danger"
              icon={<Flame className="h-3.5 w-3.5" />}
              onClick={() => injectHazard('FIRE', zones[2]?.zone_id ?? 'ZONE_C')}
            >
              Inject fire
            </Button>
            <Button
              size="sm"
              variant="subtle"
              icon={<Wind className="h-3.5 w-3.5" />}
              onClick={() => injectHazard('SMOKE', zones[2]?.zone_id ?? 'ZONE_C')}
            >
              Inject smoke
            </Button>
            <Button
              size="sm"
              variant="outline"
              icon={<Users className="h-3.5 w-3.5" />}
              onClick={triggerSurge}
            >
              Crowd surge
            </Button>
            <Button
              size="sm"
              variant="success"
              icon={<ShieldCheck className="h-3.5 w-3.5" />}
              onClick={clearHazards}
            >
              Clear all
            </Button>
          </div>
        </div>
      )}
    </Panel>
  );
}
