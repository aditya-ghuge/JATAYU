import clsx from 'clsx';
import {
  AlertOctagon,
  DoorOpen,
  Flame,
  HelpCircle,
  LogIn,
  TrendingDown,
  TrendingUp,
  Users,
} from 'lucide-react';
import type { ReactNode } from 'react';
import { useStore } from '../../lib/store';
import { AnimatedNumber, Panel, ProgressBar } from '../ui/Primitives';

interface CardProps {
  label: string;
  value: number;
  icon: ReactNode;
  tone: 'brand' | 'safe' | 'warn' | 'danger';
  suffix?: string;
  decimals?: number;
  sub?: string;
  progress?: number;
  trend?: number;
  pulse?: boolean;
}

const tones = {
  brand: {
    ring: 'ring-brand-400/20',
    icon: 'bg-brand-500/14 text-brand-300',
    glow: 'hover:shadow-[0_18px_40px_-20px_rgba(50,139,255,.85)] hover:border-brand-400/40',
    text: 'text-brand-300',
  },
  safe: {
    ring: 'ring-emerald-400/20',
    icon: 'bg-emerald-500/14 text-emerald-300',
    glow: 'hover:shadow-[0_18px_40px_-20px_rgba(34,197,94,.8)] hover:border-emerald-400/40',
    text: 'text-emerald-300',
  },
  warn: {
    ring: 'ring-amber-400/20',
    icon: 'bg-amber-500/14 text-amber-300',
    glow: 'hover:shadow-[0_18px_40px_-20px_rgba(245,158,11,.8)] hover:border-amber-400/40',
    text: 'text-amber-300',
  },
  danger: {
    ring: 'ring-red-400/25',
    icon: 'bg-red-500/16 text-red-300',
    glow: 'hover:shadow-[0_18px_40px_-20px_rgba(239,68,68,.9)] hover:border-red-400/45',
    text: 'text-red-300',
  },
} as const;

function StatCard({
  label,
  value,
  icon,
  tone,
  suffix = '',
  decimals = 0,
  sub,
  progress,
  trend,
  pulse,
}: CardProps) {
  const t = tones[tone];
  return (
    <Panel
      className={clsx(
        'group relative overflow-hidden p-4 transition-all duration-300 hover:-translate-y-1',
        t.glow,
      )}
    >
      {pulse && (
        <span className="absolute right-3 top-3 h-2 w-2 rounded-full bg-red-500">
          <span className="absolute inset-0 animate-ping rounded-full bg-red-500" />
        </span>
      )}

      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">
            {label}
          </p>
          <div className="mt-2 flex items-baseline gap-1.5">
            <AnimatedNumber
              value={value}
              decimals={decimals}
              suffix={suffix}
              className="stat-value"
            />
            {trend !== undefined && trend !== 0 && (
              <span
                className={clsx(
                  'inline-flex items-center gap-0.5 text-[11px] font-bold',
                  trend > 0 ? 'text-emerald-400' : 'text-red-400',
                )}
              >
                {trend > 0 ? (
                  <TrendingUp className="h-3 w-3" />
                ) : (
                  <TrendingDown className="h-3 w-3" />
                )}
                {Math.abs(trend)}
              </span>
            )}
          </div>
          {sub && <p className="mt-1 truncate text-[11px] text-slate-500">{sub}</p>}
        </div>

        <span
          className={clsx(
            'grid h-11 w-11 shrink-0 place-items-center rounded-xl ring-1 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6',
            t.icon,
            t.ring,
          )}
        >
          {icon}
        </span>
      </div>

      {progress !== undefined && (
        <ProgressBar value={progress} tone={tone} className="mt-3" height="h-1.5" />
      )}

      <span
        className={clsx(
          'pointer-events-none absolute -bottom-10 -right-10 h-28 w-28 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-45',
          tone === 'brand' && 'bg-brand-500',
          tone === 'safe' && 'bg-emerald-500',
          tone === 'warn' && 'bg-amber-500',
          tone === 'danger' && 'bg-red-500',
        )}
      />
    </Panel>
  );
}

export function StatCards() {
  const state = useStore((s) => s.state);
  const history = useStore((s) => s.history);

  const pop = state?.population;
  const visible = pop?.total_visible ?? 0;
  const evacuated = pop?.evacuated ?? 0;
  const entered = pop?.entered ?? 0;
  const initial = pop?.initial_population ?? Math.max(visible + evacuated, 1);
  const evacPct = pop?.evacuation_percentage ?? (evacuated / Math.max(initial, 1)) * 100;
  const remaining = pop?.remaining ?? Math.max(0, initial - evacuated);
  const unaccounted = pop?.potentially_unaccounted ?? Math.max(0, initial - evacuated - visible);
  const confirmedHazards = (state?.hazards ?? []).filter((h) => h.status !== 'DETECTING');

  const prev = history.length > 6 ? history[history.length - 6] : null;
  const visibleTrend = prev ? visible - prev.visible : 0;

  return (
    <div className="stagger grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
      <StatCard
        label="Visible Now"
        value={visible}
        icon={<Users className="h-5 w-5" />}
        tone="brand"
        sub={`${pop?.tracked ?? visible} active tracks`}
        trend={visibleTrend}
      />
      <StatCard
        label="Evacuated"
        value={evacuated}
        icon={<DoorOpen className="h-5 w-5" />}
        tone="safe"
        sub={`of ${initial} initial`}
        progress={evacPct}
      />
      <StatCard
        label="Evacuation"
        value={evacPct}
        decimals={1}
        suffix="%"
        icon={<TrendingUp className="h-5 w-5" />}
        tone={evacPct > 70 ? 'safe' : evacPct > 35 ? 'warn' : 'danger'}
        sub={`${remaining} still inside`}
        progress={evacPct}
      />
      <StatCard
        label="Unsafe Entries"
        value={entered}
        icon={<LogIn className="h-5 w-5" />}
        tone={entered > 0 ? 'danger' : 'safe'}
        sub={entered > 0 ? 'Inbound through exit line' : 'No inbound breaches'}
        pulse={entered > 0}
      />
      <StatCard
        label="Active Hazards"
        value={confirmedHazards.length}
        icon={<Flame className="h-5 w-5" />}
        tone={confirmedHazards.length > 0 ? 'danger' : 'safe'}
        sub={
          confirmedHazards.length > 0
            ? confirmedHazards.map((h) => h.type).join(', ')
            : 'All zones clear'
        }
        pulse={confirmedHazards.length > 0}
      />
      <StatCard
        label="Unaccounted"
        value={unaccounted}
        icon={unaccounted > 0 ? <AlertOctagon className="h-5 w-5" /> : <HelpCircle className="h-5 w-5" />}
        tone={unaccounted > 0 ? 'warn' : 'safe'}
        sub="Estimate only · not confirmed missing"
      />
    </div>
  );
}
