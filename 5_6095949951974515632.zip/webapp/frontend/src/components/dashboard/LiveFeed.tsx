import clsx from 'clsx';
import {
  Camera,
  CameraOff,
  Crosshair,
  DoorOpen,
  Layers,
  Maximize2,
  RefreshCw,
  Route,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { videoFeedUrl } from '../../lib/api';
import { DEMO_FRAME } from '../../lib/simulator';
import { useStore } from '../../lib/store';
import { Button, IconButton } from '../ui/Button';
import { Badge, Panel, PanelHeader, Switch } from '../ui/Primitives';

/**
 * LiveFeed
 *  - LIVE mode:  <img src="/video_feed"> MJPEG stream from FastAPI
 *  - DEMO mode:  canvas-rendered synthetic scene using simulator tracks
 * Overlays (zones, exits, boxes, trails) are drawn on a canvas sized to the frame.
 */
export function LiveFeed({ compact = false }: { compact?: boolean }) {
  const state = useStore((s) => s.state);
  const zones = useStore((s) => s.zones);
  const exits = useStore((s) => s.exits);
  const conn = useStore((s) => s.conn);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  const [showZones, setShowZones] = useState(true);
  const [showBoxes, setShowBoxes] = useState(true);
  const [showTrails, setShowTrails] = useState(true);
  const [showExits, setShowExits] = useState(true);
  const [streamKey, setStreamKey] = useState(0);
  const [streamOk, setStreamOk] = useState(false);

  const frameW = state?.frame_size?.[0] ?? DEMO_FRAME.width;
  const frameH = state?.frame_size?.[1] ?? DEMO_FRAME.height;

  const isLive = conn.mode === 'LIVE';
  const src = useMemo(() => (isLive ? videoFeedUrl() : ''), [isLive, streamKey]);

  const hazardZones = useMemo(
    () =>
      new Set(
        (state?.hazards ?? [])
          .filter((h) => h.status !== 'DETECTING')
          .map((h) => h.zone),
      ),
    [state?.hazards],
  );

  /* --------------------------------------------------- canvas draw loop */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = frameW;
    canvas.height = frameH;

    ctx.clearRect(0, 0, frameW, frameH);

    /* --- Synthetic backdrop for DEMO mode --- */
    if (!isLive) {
      const g = ctx.createLinearGradient(0, 0, frameW, frameH);
      g.addColorStop(0, '#0b1220');
      g.addColorStop(0.5, '#0e1729');
      g.addColorStop(1, '#0a0f1c');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, frameW, frameH);

      // perspective floor grid
      ctx.strokeStyle = 'rgba(148,163,184,.09)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= frameW; x += 48) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, frameH);
        ctx.stroke();
      }
      for (let y = 0; y <= frameH; y += 48) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(frameW, y);
        ctx.stroke();
      }

      // hazard glow
      for (const hz of state?.hazards ?? []) {
        const z = zones.find((zz) => zz.zone_id === hz.zone);
        if (!z) continue;
        const cx = z.polygon.reduce((a, p) => a + p[0], 0) / z.polygon.length;
        const cy = z.polygon.reduce((a, p) => a + p[1], 0) / z.polygon.length;
        const isFire = String(hz.type).toUpperCase() === 'FIRE';
        const rad = ctx.createRadialGradient(cx, cy, 4, cx, cy, 190);
        rad.addColorStop(0, isFire ? 'rgba(249,115,22,.55)' : 'rgba(148,163,184,.5)');
        rad.addColorStop(1, 'transparent');
        ctx.fillStyle = rad;
        ctx.fillRect(cx - 200, cy - 200, 400, 400);

        ctx.font = 'bold 34px system-ui';
        ctx.textAlign = 'center';
        ctx.fillText(isFire ? '🔥' : '💨', cx, cy + 10);
      }
    }

    /* --- Zones --- */
    if (showZones) {
      for (const z of zones) {
        const hazardous = hazardZones.has(z.zone_id);
        const metric = state?.population?.zones?.find((m) => m.zone_id === z.zone_id);
        const lvl = metric?.crowd_level ?? 'LOW';

        const color = hazardous
          ? '239,68,68'
          : lvl === 'CRITICAL'
            ? '220,38,38'
            : lvl === 'HIGH'
              ? '249,115,22'
              : lvl === 'MODERATE'
                ? '245,158,11'
                : '50,139,255';

        ctx.beginPath();
        z.polygon.forEach(([x, y], i) => (i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)));
        ctx.closePath();
        ctx.fillStyle = `rgba(${color},${hazardous ? 0.2 : 0.1})`;
        ctx.fill();
        ctx.strokeStyle = `rgba(${color},.85)`;
        ctx.lineWidth = hazardous ? 3 : 2;
        ctx.setLineDash(hazardous ? [10, 6] : []);
        ctx.stroke();
        ctx.setLineDash([]);

        // label pill
        const [lx, ly] = z.polygon[0];
        const text = `${z.name} · ${metric?.people ?? 0}/${z.capacity}`;
        ctx.font = 'bold 13px ui-monospace, monospace';
        const w = ctx.measureText(text).width + 16;
        ctx.fillStyle = `rgba(${color},.92)`;
        ctx.beginPath();
        ctx.roundRect(lx + 8, ly + 8, w, 24, 6);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'left';
        ctx.fillText(text, lx + 16, ly + 25);
      }
    }

    /* --- Exit lines --- */
    if (showExits) {
      for (const ex of exits) {
        const [[x1, y1], [x2, y2]] = ex.line;
        ctx.strokeStyle = ex.blocked ? 'rgba(239,68,68,.95)' : 'rgba(34,197,94,.95)';
        ctx.lineWidth = 5;
        ctx.setLineDash([16, 8]);
        ctx.lineDashOffset = -(Date.now() / 45) % 24;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.font = 'bold 12px ui-monospace, monospace';
        ctx.fillStyle = ex.blocked ? '#fca5a5' : '#86efac';
        ctx.textAlign = 'left';
        ctx.fillText(
          `${ex.blocked ? '⛔' : '🚪'} ${ex.name}`,
          Math.min(x1, x2) + 6,
          Math.min(y1, y2) - 8,
        );
      }
    }

    /* --- Tracked people --- */
    const tracks = state?.tracks ?? [];
    for (const p of tracks) {
      const [x1, y1, x2, y2] = p.bbox;
      const inHazard = p.current_zone ? hazardZones.has(p.current_zone) : false;
      const stroke = inHazard ? '#ef4444' : p.speed_state === 'RUNNING' ? '#fbbf24' : '#22c55e';

      if (showTrails && p.history && p.history.length > 1) {
        ctx.beginPath();
        p.history.forEach(([hx, hy], i) => (i === 0 ? ctx.moveTo(hx, hy) : ctx.lineTo(hx, hy)));
        ctx.strokeStyle = 'rgba(34,211,238,.6)';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      if (!isLive) {
        // draw a person glyph for the synthetic scene
        const cx = (x1 + x2) / 2;
        ctx.fillStyle = inHazard ? 'rgba(239,68,68,.9)' : 'rgba(226,232,240,.92)';
        ctx.beginPath();
        ctx.arc(cx, y1 + 10, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.roundRect(cx - 8, y1 + 20, 16, 30, 7);
        ctx.fill();
      }

      if (showBoxes) {
        ctx.strokeStyle = stroke;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(x1, y1, x2 - x1, y2 - y1, 4);
        ctx.stroke();

        // corner accents
        ctx.lineWidth = 3;
        const c = 9;
        ctx.beginPath();
        ctx.moveTo(x1, y1 + c);
        ctx.lineTo(x1, y1);
        ctx.lineTo(x1 + c, y1);
        ctx.moveTo(x2 - c, y2);
        ctx.lineTo(x2, y2);
        ctx.lineTo(x2, y2 - c);
        ctx.stroke();

        const label = `#${p.track_id} ${(p.confidence * 100).toFixed(0)}%`;
        ctx.font = 'bold 11px ui-monospace, monospace';
        const lw = ctx.measureText(label).width + 10;
        ctx.fillStyle = stroke;
        ctx.beginPath();
        ctx.roundRect(x1, y1 - 18, lw, 16, 3);
        ctx.fill();
        ctx.fillStyle = '#04070d';
        ctx.textAlign = 'left';
        ctx.fillText(label, x1 + 5, y1 - 6);
      }
    }

    /* --- HUD corner brackets --- */
    ctx.strokeStyle = 'rgba(34,211,238,.5)';
    ctx.lineWidth = 3;
    const m = 14;
    const L = 34;
    const corners: [number, number, number, number, number, number][] = [
      [m, m + L, m, m, m + L, m],
      [frameW - m - L, m, frameW - m, m, frameW - m, m + L],
      [m, frameH - m - L, m, frameH - m, m + L, frameH - m],
      [frameW - m - L, frameH - m, frameW - m, frameH - m, frameW - m, frameH - m - L],
    ];
    for (const [ax, ay, bx, by, cx2, cy2] of corners) {
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(bx, by);
      ctx.lineTo(cx2, cy2);
      ctx.stroke();
    }
  }, [state, zones, exits, showZones, showBoxes, showTrails, showExits, isLive, frameW, frameH, hazardZones]);

  const goFullscreen = () => {
    const el = wrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  };

  const tracks = state?.tracks?.length ?? state?.population?.total_visible ?? 0;

  return (
    <Panel className="overflow-hidden">
      <PanelHeader
        title="Live Tactical Feed"
        subtitle={`${state?.camera_id ?? 'CAM-01'} · ${frameW}×${frameH} · ${
          isLive ? 'MJPEG /video_feed' : 'Synthetic simulation'
        }`}
        icon={isLive ? <Camera className="h-4 w-4" /> : <CameraOff className="h-4 w-4" />}
        actions={
          <>
            <Badge tone={isLive ? 'success' : 'warn'} dot>
              {isLive ? 'LIVE' : 'DEMO'}
            </Badge>
            <IconButton
              label="Restart stream"
              variant="ghost"
              onClick={() => {
                setStreamOk(false);
                setStreamKey((k) => k + 1);
              }}
              icon={<RefreshCw className="h-4 w-4" />}
            />
            <IconButton
              label="Fullscreen"
              variant="ghost"
              onClick={goFullscreen}
              icon={<Maximize2 className="h-4 w-4" />}
            />
          </>
        }
      />

      <div
        ref={wrapRef}
        className="relative bg-black scan-overlay"
        style={{ aspectRatio: `${frameW}/${frameH}` }}
      >
        {isLive && (
          <img
            key={streamKey}
            ref={imgRef}
            src={src}
            alt="Live CCTV stream"
            onLoad={() => setStreamOk(true)}
            onError={() => setStreamOk(false)}
            className="absolute inset-0 h-full w-full object-contain"
          />
        )}

        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full object-contain"
        />

        {isLive && !streamOk && (
          <div className="absolute inset-0 grid place-content-center gap-2 bg-black/70 text-center">
            <p className="text-xs font-bold uppercase tracking-widest text-amber-300">
              Awaiting MJPEG frames
            </p>
            <p className="text-[11px] text-slate-500">
              Overlay is live from /state · stream will appear when frames arrive
            </p>
          </div>
        )}

        {/* Top-left HUD readout */}
        <div className="pointer-events-none absolute left-4 top-4 space-y-1 font-mono text-[10px] font-bold uppercase tracking-widest">
          <p className="text-cyan-300">REC ● {new Date().toLocaleTimeString([], { hour12: false })}</p>
          <p className="text-slate-400">TRACKS: {tracks}</p>
          <p className="text-slate-400">FPS: {(state?.fps ?? 0).toFixed(1)}</p>
        </div>

        {/* Critical banner */}
        {hazardZones.size > 0 && (
          <div className="pointer-events-none absolute left-1/2 top-1/4 -translate-x-1/2">
            <div className="animate-blink rounded-xl border-2 border-red-500 bg-red-950/80 px-5 py-2.5 text-center shadow-[0_0_50px_-8px_rgba(239,68,68,1)]">
              <p className="text-sm font-black uppercase tracking-[0.15em] text-red-300">
                ⚠ Critical Hazard Confirmed
              </p>
              <p className="mt-0.5 font-mono text-[10px] text-red-400/90">
                {[...hazardZones].join(' · ')}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Overlay toggles */}
      {!compact && (
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5 border-t border-white/[0.07] px-4 py-3">
          <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-500">
            <Layers className="h-3.5 w-3.5" /> Overlays
          </span>
          <Switch checked={showZones} onChange={setShowZones} label="Zones" />
          <Switch checked={showBoxes} onChange={setShowBoxes} label="Bounding boxes" />
          <Switch checked={showTrails} onChange={setShowTrails} label="Motion trails" />
          <Switch checked={showExits} onChange={setShowExits} label="Exit lines" />
          <div className="ml-auto flex items-center gap-2">
            <Badge tone="info">
              <Crosshair className="h-3 w-3" /> {tracks} tracked
            </Badge>
            <Badge tone="success">
              <DoorOpen className="h-3 w-3" /> {exits.length} exits
            </Badge>
            <Badge tone="neutral">
              <Route className="h-3 w-3" /> {zones.length} zones
            </Badge>
          </div>
        </div>
      )}
    </Panel>
  );
}
