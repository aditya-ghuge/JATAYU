import { Activity, BarChart3, PieChart as PieIcon } from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useStore } from '../../lib/store';
import { EmptyState, Panel, PanelHeader } from '../ui/Primitives';

/** Stable empty-array identity so selectors never emit a new reference. */
const EMPTY_ZONES: never[] = [];

const axis = {
  stroke: 'rgba(148,163,184,.35)',
  tick: { fill: '#64748b', fontSize: 10, fontFamily: 'ui-monospace' },
};

const tooltipStyle = {
  contentStyle: {
    background: 'rgba(10,16,32,.96)',
    border: '1px solid rgba(255,255,255,.1)',
    borderRadius: 12,
    fontSize: 11,
    boxShadow: '0 18px 40px -18px rgba(0,0,0,.9)',
  },
  labelStyle: { color: '#94a3b8', fontSize: 10, fontWeight: 700 },
};

/** Population + evacuation over time. */
export function PopulationChart({ height = 260 }: { height?: number }) {
  const history = useStore((s) => s.history);

  return (
    <Panel>
      <PanelHeader
        title="Population & Evacuation Timeline"
        subtitle="Rolling 90 samples of /state"
        icon={<Activity className="h-4 w-4" />}
      />
      <div className="p-3" style={{ height }}>
        {history.length < 2 ? (
          <EmptyState title="Collecting telemetry…" body="Chart renders after a few samples." />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={history} margin={{ top: 8, right: 10, left: -18, bottom: 0 }}>
              <defs>
                <linearGradient id="gVisible" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#328bff" stopOpacity={0.55} />
                  <stop offset="100%" stopColor="#328bff" stopOpacity={0.02} />
                </linearGradient>
                <linearGradient id="gEvac" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22c55e" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#22c55e" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 5" stroke="rgba(255,255,255,.055)" vertical={false} />
              <XAxis dataKey="label" {...axis} interval="preserveEnd" minTickGap={40} />
              <YAxis {...axis} allowDecimals={false} />
              <RTooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10, paddingTop: 6 }} iconType="circle" />
              <Area
                type="monotone"
                dataKey="visible"
                name="Visible"
                stroke="#59adff"
                strokeWidth={2}
                fill="url(#gVisible)"
              />
              <Area
                type="monotone"
                dataKey="evacuated"
                name="Evacuated"
                stroke="#22c55e"
                strokeWidth={2}
                fill="url(#gEvac)"
              />
              <Line
                type="monotone"
                dataKey="entered"
                name="Unsafe entries"
                stroke="#ef4444"
                strokeWidth={2}
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </Panel>
  );
}

/** Per-zone occupancy bars. */
export function ZoneBarChart({ height = 260 }: { height?: number }) {
  // NOTE: select the raw slice — never `?? []` inside a selector, that returns a
  // fresh array identity on every store read and re-renders forever (React #185).
  const zonesRaw = useStore((s) => s.state?.population?.zones);
  const zones = zonesRaw ?? EMPTY_ZONES;

  const data = zones.map((z) => ({
    name: z.zone_id.replace('ZONE_', 'Z'),
    full: z.name,
    people: z.people,
    capacity: z.capacity,
    occupancy: z.occupancy_percent,
    level: z.crowd_level,
  }));

  const color = (lvl: string) =>
    lvl === 'CRITICAL' ? '#dc2626' : lvl === 'HIGH' ? '#f97316' : lvl === 'MODERATE' ? '#f59e0b' : '#22c55e';

  return (
    <Panel>
      <PanelHeader
        title="Zone Occupancy"
        subtitle="Current headcount vs configured capacity"
        icon={<BarChart3 className="h-4 w-4" />}
      />
      <div className="p-3" style={{ height }}>
        {data.length === 0 ? (
          <EmptyState title="No zones configured" />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 8, right: 10, left: -18, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 5" stroke="rgba(255,255,255,.055)" vertical={false} />
              <XAxis dataKey="name" {...axis} />
              <YAxis {...axis} allowDecimals={false} />
              <RTooltip
                {...tooltipStyle}
                formatter={(v: number, n: string) => [v, n === 'people' ? 'People' : 'Capacity']}
                labelFormatter={(l) => data.find((d) => d.name === l)?.full ?? l}
              />
              <Bar dataKey="capacity" name="Capacity" fill="rgba(255,255,255,.08)" radius={[5, 5, 0, 0]} />
              <Bar dataKey="people" name="People" radius={[5, 5, 0, 0]}>
                {data.map((d, i) => (
                  <Cell key={i} fill={color(d.level)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </Panel>
  );
}

/** Event distribution donut. */
export function EventDonut({ height = 260 }: { height?: number }) {
  const events = useStore((s) => s.events);

  const counts = new Map<string, number>();
  for (const e of events) {
    const k = String(e.priority).toUpperCase();
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  const palette: Record<string, string> = {
    CRITICAL: '#dc2626',
    HIGH: '#f97316',
    MEDIUM: '#f59e0b',
    LOW: '#328bff',
    INFO: '#64748b',
  };
  const data = [...counts.entries()].map(([name, value]) => ({ name, value }));

  return (
    <Panel>
      <PanelHeader
        title="Event Severity Mix"
        subtitle={`${events.length} events in buffer`}
        icon={<PieIcon className="h-4 w-4" />}
      />
      <div className="p-3" style={{ height }}>
        {data.length === 0 ? (
          <EmptyState title="No events recorded" />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius="52%"
                outerRadius="80%"
                paddingAngle={3}
                stroke="rgba(7,11,20,.9)"
                strokeWidth={2}
              >
                {data.map((d, i) => (
                  <Cell key={i} fill={palette[d.name] ?? '#475569'} />
                ))}
              </Pie>
              <RTooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} iconType="circle" />
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>
    </Panel>
  );
}

/** Zone risk radar (occupancy + hazard weighting). */
export function RiskRadar({ height = 260 }: { height?: number }) {
  const state = useStore((s) => s.state);
  const zones = state?.population?.zones ?? [];
  const hazardZones = new Set((state?.hazards ?? []).map((h) => h.zone));

  const data = zones.map((z) => ({
    zone: z.zone_id.replace('ZONE_', 'Z'),
    risk: Math.min(
      100,
      Math.round(z.occupancy_percent * 0.6 + (hazardZones.has(z.zone_id) ? 45 : 0)),
    ),
    occupancy: Math.min(100, z.occupancy_percent),
  }));

  return (
    <Panel>
      <PanelHeader
        title="Zone Risk Profile"
        subtitle="Occupancy weighted with active hazards"
        icon={<Activity className="h-4 w-4" />}
      />
      <div className="p-3" style={{ height }}>
        {data.length < 3 ? (
          <EmptyState title="Need at least 3 zones" body="Radar plot requires 3+ configured zones." />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={data} outerRadius="72%">
              <PolarGrid stroke="rgba(255,255,255,.09)" />
              <PolarAngleAxis dataKey="zone" tick={{ fill: '#64748b', fontSize: 10 }} />
              <RTooltip {...tooltipStyle} />
              <Radar
                name="Risk index"
                dataKey="risk"
                stroke="#ef4444"
                fill="#ef4444"
                fillOpacity={0.28}
                strokeWidth={2}
              />
              <Radar
                name="Occupancy %"
                dataKey="occupancy"
                stroke="#328bff"
                fill="#328bff"
                fillOpacity={0.18}
                strokeWidth={2}
              />
              <Legend wrapperStyle={{ fontSize: 10 }} iconType="circle" />
            </RadarChart>
          </ResponsiveContainer>
        )}
      </div>
    </Panel>
  );
}
