import clsx from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BellRing,
  Check,
  CheckCheck,
  DoorOpen,
  Flame,
  Footprints,
  Info,
  LogIn,
  ShieldAlert,
  Users,
  Wind,
} from 'lucide-react';
import type { ReactNode } from 'react';
import { useStore } from '../../lib/store';
import type { SystemEvent } from '../../lib/types';
import { Button, IconButton } from '../ui/Button';
import { Badge, EmptyState, Panel, PanelHeader } from '../ui/Primitives';

const priorityStyle: Record<string, string> = {
  CRITICAL: 'border-l-red-500 bg-red-500/[0.06]',
  HIGH: 'border-l-orange-500 bg-orange-500/[0.05]',
  MEDIUM: 'border-l-amber-500 bg-amber-500/[0.04]',
  LOW: 'border-l-brand-500 bg-brand-500/[0.04]',
  INFO: 'border-l-slate-600 bg-white/[0.02]',
};

const priorityTone: Record<string, 'danger' | 'warn' | 'info' | 'neutral'> = {
  CRITICAL: 'danger',
  HIGH: 'warn',
  MEDIUM: 'warn',
  LOW: 'info',
  INFO: 'neutral',
};

function eventIcon(type: string): ReactNode {
  const t = type.toUpperCase();
  if (t.includes('FIRE')) return <Flame className="h-4 w-4" />;
  if (t.includes('SMOKE')) return <Wind className="h-4 w-4" />;
  if (t.includes('DEBRIS') || t.includes('BLOCKED')) return <ShieldAlert className="h-4 w-4" />;
  if (t.includes('EXIT_CROSSED')) return <DoorOpen className="h-4 w-4" />;
  if (t.includes('ENTRY')) return <LogIn className="h-4 w-4" />;
  if (t.includes('MOVEMENT')) return <Footprints className="h-4 w-4" />;
  if (t.includes('SURGE')) return <Users className="h-4 w-4" />;
  return <Info className="h-4 w-4" />;
}

function relTime(iso: string) {
  const d = Date.now() - new Date(iso).getTime();
  if (Number.isNaN(d)) return '—';
  const s = Math.floor(d / 1000);
  if (s < 5) return 'now';
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

export function EventRow({ e, compact = false }: { e: SystemEvent; compact?: boolean }) {
  const acked = useStore((s) => s.acked);
  const ackEvent = useStore((s) => s.ackEvent);
  const p = String(e.priority).toUpperCase();
  const isAcked = acked.has(e.event_id);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -14 }}
      animate={{ opacity: isAcked ? 0.5 : 1, x: 0 }}
      exit={{ opacity: 0, x: 14 }}
      transition={{ type: 'spring', stiffness: 320, damping: 30 }}
      className={clsx(
        'group flex items-start gap-3 border-l-2 px-3.5 py-2.5 transition-colors hover:bg-white/[0.045]',
        priorityStyle[p] ?? priorityStyle.INFO,
      )}
    >
      <span
        className={clsx(
          'mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg',
          p === 'CRITICAL'
            ? 'bg-red-500/16 text-red-300'
            : p === 'HIGH'
              ? 'bg-orange-500/16 text-orange-300'
              : 'bg-white/[0.06] text-slate-400',
          p === 'CRITICAL' && !isAcked && 'animate-blink',
        )}
      >
        {eventIcon(String(e.type))}
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <p className="text-xs font-bold uppercase tracking-wide text-white">
            {String(e.type).replace(/_/g, ' ')}
          </p>
          <Badge tone={priorityTone[p] ?? 'neutral'}>{p}</Badge>
          {isAcked && <Badge tone="success">ACK</Badge>}
        </div>

        {e.data?.message && (
          <p className="mt-1 break-words text-[11px] leading-snug text-slate-400">
            {e.data.message}
          </p>
        )}

        {!compact && (
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] text-slate-600">
            <span>{e.event_id}</span>
            {e.data?.zone && <span className="text-brand-400/80">zone {e.data.zone}</span>}
            {e.data?.track_id != null && (
              <span className="text-cyan-400/80">#{e.data.track_id}</span>
            )}
            {e.data?.from_zone && e.data?.to_zone && (
              <span className="text-amber-400/80">
                {e.data.from_zone} → {e.data.to_zone}
              </span>
            )}
            {e.data?.confidence != null && (
              <span>{(Number(e.data.confidence) * 100).toFixed(0)}% conf</span>
            )}
          </div>
        )}
      </div>

      <div className="flex shrink-0 flex-col items-end gap-1.5">
        <span className="whitespace-nowrap font-mono text-[10px] text-slate-500">
          {relTime(e.timestamp)}
        </span>
        {!isAcked && (
          <IconButton
            label="Acknowledge"
            variant="ghost"
            onClick={() => ackEvent(e.event_id)}
            className="h-7 w-7 opacity-0 transition-opacity group-hover:opacity-100"
            icon={<Check className="h-3.5 w-3.5" />}
          />
        )}
      </div>
    </motion.div>
  );
}

export function EventFeed({ limit = 12 }: { limit?: number }) {
  const events = useStore((s) => s.events);
  const acked = useStore((s) => s.acked);
  const ackAll = useStore((s) => s.ackAll);

  const sorted = [...events].reverse().slice(0, limit);
  const pending = events.filter(
    (e) => !acked.has(e.event_id) && ['CRITICAL', 'HIGH'].includes(String(e.priority).toUpperCase()),
  ).length;

  return (
    <Panel className="flex h-full flex-col overflow-hidden">
      <PanelHeader
        title="Live Event Stream"
        subtitle={`${events.length} events buffered · GET /events`}
        icon={<BellRing className="h-4 w-4" />}
        actions={
          <>
            {pending > 0 && (
              <Badge tone="danger" dot>
                {pending} pending
              </Badge>
            )}
            <Button
              size="sm"
              variant="ghost"
              onClick={ackAll}
              icon={<CheckCheck className="h-3.5 w-3.5" />}
            >
              Ack all
            </Button>
          </>
        }
      />

      <div className="flex-1 divide-y divide-white/[0.045] overflow-y-auto">
        {sorted.length === 0 ? (
          <EmptyState
            icon={<BellRing className="h-6 w-6" />}
            title="No events yet"
            body="Hazard confirmations, exit crossings and unsafe movements will stream in here."
          />
        ) : (
          <AnimatePresence initial={false}>
            {sorted.map((e) => (
              <EventRow key={e.event_id} e={e} compact />
            ))}
          </AnimatePresence>
        )}
      </div>
    </Panel>
  );
}
