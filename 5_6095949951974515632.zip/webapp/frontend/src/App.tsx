import clsx from 'clsx';
import { useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Sidebar } from './components/layout/Sidebar';
import { Topbar } from './components/layout/Topbar';
import { ToastHost } from './components/ui/Toasts';
import { useStore } from './lib/store';
import Analytics from './pages/Analytics';
import Dashboard from './pages/Dashboard';
import EventLog from './pages/EventLog';
import LiveView from './pages/LiveView';
import Settings from './pages/Settings';
import ZoneControl from './pages/ZoneControl';

export default function App() {
  const boot = useStore((s) => s.boot);
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    boot();
  }, [boot]);

  useEffect(() => {
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return (
    <div className="min-h-screen">
      <Sidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed(!collapsed)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div
        className={clsx(
          'transition-[padding] duration-300 ease-out',
          collapsed ? 'lg:pl-[76px]' : 'lg:pl-[248px]',
        )}
      >
        <Topbar onOpenMenu={() => setMobileOpen(true)} />

        <main key={location.pathname} className="animate-fade-in p-4 pb-10 sm:p-5">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/live" element={<LiveView />} />
            <Route path="/zones" element={<ZoneControl />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/events" element={<EventLog />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>

          <footer className="mt-8 border-t border-white/[0.06] pt-4">
            <p className="text-center text-[11px] text-slate-600">
              <span className="font-bold text-slate-500">JATAYU</span> · PS14 CCTV Disaster
              Intelligence &amp; Evacuation Monitoring · schema v1.0
            </p>
          </footer>
        </main>
      </div>

      <ToastHost />
    </div>
  );
}
