/**
 * Global application store (Zustand).
 *
 * Owns the polling loop:  /health -> /state -> /events
 * If the live backend is unreachable it transparently switches to the
 * built-in Simulator so the whole UI stays functional (DEMO mode).
 */

import { create } from 'zustand';
import { api, getApiBase, setApiBase } from './api';
import { DEMO_EXITS, DEMO_ZONES, simulator } from './simulator';
import type {
  ConnectionInfo,
  ExitConfig,
  HealthResponse,
  Sample,
  SystemEvent,
  SystemState,
  ZoneConfig,
} from './types';

export type Toast = {
  id: string;
  title: string;
  body?: string;
  tone: 'info' | 'success' | 'warn' | 'danger';
};

const ACK_KEY = 'jatayu.ackEvents';
const SOUND_KEY = 'jatayu.sound';
const INTERVAL_KEY = 'jatayu.pollMs';

function loadAcks(): Set<string> {
  try {
    return new Set(JSON.parse(localStorage.getItem(ACK_KEY) ?? '[]'));
  } catch {
    return new Set();
  }
}

function beep(tone: 'alert' | 'critical') {
  if (localStorage.getItem(SOUND_KEY) === 'off') return;
  try {
    const Ctx =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = 'sine';
    osc.frequency.value = tone === 'critical' ? 880 : 620;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.14, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.4);
    osc.start();
    osc.stop(ctx.currentTime + 0.42);
    setTimeout(() => ctx.close(), 700);
  } catch {
    /* audio unavailable — silent */
  }
}

interface AppStore {
  // data
  state: SystemState | null;
  events: SystemEvent[];
  zones: ZoneConfig[];
  exits: ExitConfig[];
  health: HealthResponse | null;
  history: Sample[];

  // meta
  conn: ConnectionInfo;
  apiBase: string;
  pollMs: number;
  paused: boolean;
  soundOn: boolean;
  toasts: Toast[];
  acked: Set<string>;
  booted: boolean;

  // actions
  boot: () => void;
  poll: () => Promise<void>;
  setApiBaseUrl: (v: string) => void;
  setPollMs: (v: number) => void;
  togglePause: () => void;
  toggleSound: () => void;
  forceDemo: (on: boolean) => void;
  ackEvent: (id: string) => void;
  ackAll: () => void;
  clearAcks: () => void;
  pushToast: (t: Omit<Toast, 'id'>) => void;
  dismissToast: (id: string) => void;
  resetCounters: () => Promise<void>;
  injectHazard: (t: 'FIRE' | 'SMOKE' | 'DEBRIS', zone?: string) => void;
  clearHazards: () => void;
  triggerSurge: () => void;
  saveZones: (z: ZoneConfig[]) => Promise<void>;
  saveExits: (e: ExitConfig[]) => Promise<void>;
  switchSource: (t: string, p: string) => Promise<void>;
}

let timer: number | null = null;
let seenEventIds = new Set<string>();
let demoForced = false;

export const useStore = create<AppStore>((set, get) => ({
  state: null,
  events: [],
  zones: [],
  exits: [],
  health: null,
  history: [],

  conn: { connected: false, latencyMs: null, lastSuccess: null, error: null, mode: 'DEMO' },
  apiBase: getApiBase(),
  pollMs: Number(localStorage.getItem(INTERVAL_KEY) ?? 1000),
  paused: false,
  soundOn: localStorage.getItem(SOUND_KEY) !== 'off',
  toasts: [],
  acked: loadAcks(),
  booted: false,

  boot: () => {
    if (get().booted) return;
    set({ booted: true });
    const loop = async () => {
      // The timer MUST always re-arm. If a poll throws (bad payload, audio
      // context, JSON edge case) an unguarded await would kill the loop
      // permanently and freeze the dashboard on its last state.
      try {
        if (!get().paused) await get().poll();
      } catch (err) {
        console.error('[jatayu] poll cycle failed:', err);
        set({
          conn: {
            ...get().conn,
            connected: false,
            error: err instanceof Error ? err.message : 'Poll failed',
          },
        });
      } finally {
        timer = window.setTimeout(loop, get().pollMs);
      }
    };
    if (timer) window.clearTimeout(timer);
    loop();
  },

  poll: async () => {
    const useDemo = demoForced;

    if (!useDemo) {
      const stateRes = await api.state();

      if (stateRes.data && stateRes.data.population) {
        // ---------- LIVE ----------
        const [eventsRes, healthRes] = await Promise.all([api.events(), api.health()]);

        if (get().zones.length === 0) {
          const z = await api.zones();
          if (z.data?.length) set({ zones: z.data });
          const e = await api.exits();
          if (e.data?.length) set({ exits: e.data });
        }

        const s = stateRes.data;
        const evts = eventsRes.data?.events ?? get().events;
        applyUpdate(set, get, s, evts, {
          connected: true,
          latencyMs: stateRes.latencyMs,
          lastSuccess: Date.now(),
          error: null,
          mode: 'LIVE',
        });
        if (healthRes.data) set({ health: healthRes.data });
        return;
      }

      // ---------- fell through to DEMO ----------
      const s = simulator.step();
      applyUpdate(set, get, s, simulator.getEvents(), {
        connected: false,
        latencyMs: null,
        lastSuccess: get().conn.lastSuccess,
        error: stateRes.error ?? 'Backend unreachable',
        mode: 'DEMO',
      });
      if (get().zones.length === 0) set({ zones: DEMO_ZONES, exits: DEMO_EXITS });
      return;
    }

    // ---------- forced DEMO ----------
    const s = simulator.step();
    applyUpdate(set, get, s, simulator.getEvents(), {
      connected: false,
      latencyMs: null,
      lastSuccess: get().conn.lastSuccess,
      error: null,
      mode: 'DEMO',
    });
    if (get().zones.length === 0) set({ zones: DEMO_ZONES, exits: DEMO_EXITS });
  },

  setApiBaseUrl: (v) => {
    setApiBase(v);
    set({ apiBase: getApiBase(), zones: [], exits: [] });
    get().pushToast({ title: 'API endpoint updated', body: getApiBase(), tone: 'info' });
  },

  setPollMs: (v) => {
    localStorage.setItem(INTERVAL_KEY, String(v));
    set({ pollMs: v });
  },

  togglePause: () => {
    const paused = !get().paused;
    set({ paused });
    get().pushToast({
      title: paused ? 'Live feed paused' : 'Live feed resumed',
      tone: paused ? 'warn' : 'success',
    });
  },

  toggleSound: () => {
    const soundOn = !get().soundOn;
    localStorage.setItem(SOUND_KEY, soundOn ? 'on' : 'off');
    set({ soundOn });
  },

  forceDemo: (on) => {
    demoForced = on;
    set({ zones: [], exits: [] });
    get().pushToast({
      title: on ? 'Demo simulation enabled' : 'Reconnecting to live backend',
      tone: on ? 'info' : 'success',
    });
  },

  ackEvent: (id) => {
    const acked = new Set(get().acked);
    acked.add(id);
    localStorage.setItem(ACK_KEY, JSON.stringify([...acked]));
    set({ acked });
  },

  ackAll: () => {
    const acked = new Set(get().acked);
    get().events.forEach((e) => acked.add(e.event_id));
    localStorage.setItem(ACK_KEY, JSON.stringify([...acked]));
    set({ acked });
    get().pushToast({ title: 'All alerts acknowledged', tone: 'success' });
  },

  clearAcks: () => {
    localStorage.removeItem(ACK_KEY);
    set({ acked: new Set() });
  },

  pushToast: (t) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    set({ toasts: [...get().toasts, { ...t, id }].slice(-4) });
    window.setTimeout(() => get().dismissToast(id), 5200);
  },

  dismissToast: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),

  resetCounters: async () => {
    if (get().conn.mode === 'LIVE') {
      const r = await api.reset();
      get().pushToast(
        r.error
          ? { title: 'Reset failed', body: r.error, tone: 'danger' }
          : { title: 'Evacuation counters reset', tone: 'success' },
      );
    } else {
      simulator.reset();
      get().pushToast({ title: 'Simulation reset', tone: 'success' });
    }
  },

  injectHazard: (t, zone) => {
    simulator.injectHazard(t, zone);
    get().pushToast({ title: `${t} injected`, body: zone ?? 'ZONE_C', tone: 'warn' });
  },

  clearHazards: () => {
    simulator.clearHazards();
    get().pushToast({ title: 'Hazards cleared', tone: 'success' });
  },

  triggerSurge: () => {
    simulator.surge(6);
    get().pushToast({ title: 'Crowd surge injected', tone: 'warn' });
  },

  saveZones: async (z) => {
    set({ zones: z });
    if (get().conn.mode === 'LIVE') {
      const r = await api.saveZones(z);
      get().pushToast(
        r.error
          ? { title: 'Zone save failed', body: r.error, tone: 'danger' }
          : { title: 'Zones synced to backend', tone: 'success' },
      );
    } else {
      get().pushToast({ title: 'Zones saved locally', body: 'Demo mode', tone: 'info' });
    }
  },

  saveExits: async (e) => {
    set({ exits: e });
    if (get().conn.mode === 'LIVE') {
      const r = await api.saveExits(e);
      get().pushToast(
        r.error
          ? { title: 'Exit save failed', body: r.error, tone: 'danger' }
          : { title: 'Exits synced to backend', tone: 'success' },
      );
    } else {
      get().pushToast({ title: 'Exits saved locally', body: 'Demo mode', tone: 'info' });
    }
  },

  switchSource: async (t, p) => {
    const r = await api.setSource(t, p);
    get().pushToast(
      r.error
        ? { title: 'Source switch failed', body: r.error, tone: 'danger' }
        : { title: 'Video source switched', body: `${t}: ${p}`, tone: 'success' },
    );
  },
}));

/** Shared update path for both LIVE and DEMO data. */
function applyUpdate(
  set: (partial: Partial<AppStore>) => void,
  get: () => AppStore,
  s: SystemState,
  events: SystemEvent[],
  conn: ConnectionInfo,
) {
  const prev = get();

  // rolling history for charts
  const zones = s.population?.zones ?? [];
  const avgOcc =
    zones.length > 0
      ? zones.reduce((a, z) => a + (z.occupancy_percent ?? 0), 0) / zones.length
      : 0;

  const sample: Sample = {
    t: Date.now(),
    label: new Date().toLocaleTimeString([], { minute: '2-digit', second: '2-digit' }),
    visible: s.population?.total_visible ?? 0,
    evacuated: s.population?.evacuated ?? 0,
    entered: s.population?.entered ?? 0,
    hazards: (s.hazards ?? []).filter((h) => h.status !== 'DETECTING').length,
    occupancy: Math.round(avgOcc * 10) / 10,
  };

  const history = [...prev.history, sample].slice(-90);

  // new-event notifications
  const fresh = events.filter((e) => !seenEventIds.has(e.event_id));
  if (seenEventIds.size === 0) {
    events.forEach((e) => seenEventIds.add(e.event_id));
  } else {
    for (const e of fresh) {
      seenEventIds.add(e.event_id);
      const p = String(e.priority).toUpperCase();
      if (p === 'CRITICAL' || p === 'HIGH') {
        prev.pushToast({
          title: String(e.type).replace(/_/g, ' '),
          body: e.data?.message ?? '',
          tone: p === 'CRITICAL' ? 'danger' : 'warn',
        });
        beep(p === 'CRITICAL' ? 'critical' : 'alert');
      }
    }
  }
  if (seenEventIds.size > 400) seenEventIds = new Set([...seenEventIds].slice(-200));

  set({ state: s, events, history, conn });
}
