/**
 * DEMO SIMULATOR
 *
 * A faithful client-side reimplementation of the backend engines
 * (tracker.py, crowd/engine.py, evacuation/engine.py, hazards/hazard_engine.py)
 * so the command center is fully explorable when the Python service is offline.
 *
 * It emits the exact same `SystemState` / `SystemEvent` shapes as the real API,
 * which means every component is driven by one contract — no branching in the UI.
 */

import type {
  CrowdLevel,
  ExitConfig,
  HazardEntry,
  SystemEvent,
  SystemState,
  TrackedPerson,
  ZoneConfig,
} from './types';

const W = 960;
const H = 540;

export const DEMO_ZONES: ZoneConfig[] = [
  {
    zone_id: 'ZONE_A',
    name: 'North Corridor',
    capacity: 14,
    polygon: [
      [30, 30],
      [460, 30],
      [460, 250],
      [30, 250],
    ],
  },
  {
    zone_id: 'ZONE_B',
    name: 'Main Concourse',
    capacity: 20,
    polygon: [
      [500, 30],
      [930, 30],
      [930, 250],
      [500, 250],
    ],
  },
  {
    zone_id: 'ZONE_C',
    name: 'East Wing',
    capacity: 10,
    polygon: [
      [500, 285],
      [930, 285],
      [930, 505],
      [500, 505],
    ],
    critical: true,
  },
  {
    zone_id: 'ZONE_D',
    name: 'Exit Lobby',
    capacity: 16,
    polygon: [
      [30, 285],
      [460, 285],
      [460, 505],
      [30, 505],
    ],
  },
];

export const DEMO_EXITS: ExitConfig[] = [
  { exit_id: 'EXIT_A', name: 'Main Door', line: [[30, 470], [460, 470]] },
  { exit_id: 'EXIT_B', name: 'Service Door', line: [[905, 285], [905, 505]] },
];

interface Agent {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  history: [number, number][];
  exited: boolean;
  entered: boolean;
  zone: string | null;
  panic: number;
}

function pointInPolygon(p: [number, number], poly: [number, number][]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > p[1] !== yj > p[1] && p[0] < ((xj - xi) * (p[1] - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

function segmentsIntersect(
  p1: [number, number],
  p2: [number, number],
  p3: [number, number],
  p4: [number, number],
) {
  const ccw = (a: number[], b: number[], c: number[]) =>
    (c[1] - a[1]) * (b[0] - a[0]) > (b[1] - a[1]) * (c[0] - a[0]);
  return (
    ccw(p1, p3, p4) !== ccw(p2, p3, p4) && ccw(p1, p2, p3) !== ccw(p1, p2, p4)
  );
}

function crowdLevel(pct: number): CrowdLevel {
  if (pct <= 40) return 'LOW';
  if (pct <= 70) return 'MODERATE';
  if (pct <= 100) return 'HIGH';
  return 'CRITICAL';
}

export class Simulator {
  private agents: Agent[] = [];
  private nextId = 1;
  private tick = 0;
  private evacuatedIds = new Set<number>();
  private enteredIds = new Set<number>();
  private initialPopulation = 24;
  private events: SystemEvent[] = [];
  private eventSeq = 1;
  private hazards = new Map<string, { type: string; zone: string; frames: number; conf: number }>();
  private hazardScheduled = false;

  constructor() {
    for (let i = 0; i < this.initialPopulation; i++) this.spawn();
    this.pushEvent('SYSTEM', 'INFO', { message: 'Demo simulation engine initialised' });
  }

  private spawn(x?: number, y?: number) {
    const a: Agent = {
      id: this.nextId++,
      x: x ?? 60 + Math.random() * (W - 120),
      y: y ?? 60 + Math.random() * (H - 200),
      vx: (Math.random() - 0.5) * 2.2,
      vy: (Math.random() - 0.5) * 2.2,
      history: [],
      exited: false,
      entered: false,
      zone: null,
      panic: 0,
    };
    a.history.push([Math.round(a.x), Math.round(a.y)]);
    this.agents.push(a);
    return a;
  }

  private pushEvent(type: string, priority: string, data: Record<string, unknown>) {
    const ev: SystemEvent = {
      event_id: `EVT-${String(this.eventSeq++).padStart(5, '0')}`,
      timestamp: new Date().toISOString(),
      type,
      priority,
      data,
    };
    this.events.push(ev);
    if (this.events.length > 120) this.events.shift();
  }

  /** Manually trigger a hazard from the UI (demo control). */
  injectHazard(type: 'FIRE' | 'SMOKE' | 'DEBRIS', zone = 'ZONE_C') {
    const key = `${type}|${zone}`;
    this.hazards.set(key, { type, zone, frames: 14, conf: 0.72 + Math.random() * 0.2 });
  }

  clearHazards() {
    this.hazards.clear();
    this.pushEvent('SYSTEM', 'INFO', { message: 'All hazards manually cleared' });
  }

  surge(n = 6) {
    for (let i = 0; i < n; i++) this.spawn(80 + Math.random() * 300, 480);
    this.initialPopulation += n;
    this.pushEvent('CROWD_SURGE', 'HIGH', {
      message: `Crowd surge detected — ${n} new subjects entering Exit Lobby`,
      zone: 'ZONE_D',
    });
  }

  reset() {
    this.agents = [];
    this.nextId = 1;
    this.evacuatedIds.clear();
    this.enteredIds.clear();
    this.hazards.clear();
    this.initialPopulation = 24;
    this.hazardScheduled = false;
    for (let i = 0; i < this.initialPopulation; i++) this.spawn();
    this.pushEvent('SYSTEM', 'INFO', { message: 'Evacuation counters reset' });
  }

  step(): SystemState {
    this.tick++;

    // auto-ignite a fire after a while to make the demo tell a story
    if (!this.hazardScheduled && this.tick === 40) {
      this.hazardScheduled = true;
      this.injectHazard('FIRE', 'ZONE_C');
    }
    if (this.tick === 70) this.injectHazard('SMOKE', 'ZONE_C');

    const activeHazardZones = new Set(
      [...this.hazards.values()].filter((h) => h.frames >= 15).map((h) => h.zone),
    );

    // ---- move agents ----
    for (const a of this.agents) {
      if (a.exited) continue;

      // hazard avoidance: flee from critical zones toward Exit Lobby
      if (activeHazardZones.size > 0) {
        a.panic = Math.min(1, a.panic + 0.02);
        const target = { x: 240, y: 470 };
        const dx = target.x - a.x;
        const dy = target.y - a.y;
        const d = Math.hypot(dx, dy) || 1;
        a.vx += (dx / d) * 0.28 * a.panic;
        a.vy += (dy / d) * 0.28 * a.panic;
      }

      a.vx += (Math.random() - 0.5) * 0.5;
      a.vy += (Math.random() - 0.5) * 0.5;

      const speed = Math.hypot(a.vx, a.vy);
      const max = 1.9 + a.panic * 2.6;
      if (speed > max) {
        a.vx = (a.vx / speed) * max;
        a.vy = (a.vy / speed) * max;
      }

      const prev: [number, number] = [Math.round(a.x), Math.round(a.y)];
      a.x += a.vx;
      a.y += a.vy;

      if (a.x < 20 || a.x > W - 20) a.vx *= -1;
      if (a.y < 20 || a.y > H - 20) a.vy *= -1;
      a.x = Math.max(20, Math.min(W - 20, a.x));
      a.y = Math.max(20, Math.min(H - 20, a.y));

      const now: [number, number] = [Math.round(a.x), Math.round(a.y)];
      a.history.push(now);
      if (a.history.length > 30) a.history.shift();

      // ---- exit line crossing (evacuation/engine.py logic) ----
      if (!a.exited && !a.entered) {
        for (const ex of DEMO_EXITS) {
          if (segmentsIntersect(prev, now, ex.line[0], ex.line[1])) {
            const vx = ex.line[1][0] - ex.line[0][0];
            const vy = ex.line[1][1] - ex.line[0][1];
            const cross = vx * (now[1] - prev[1]) - vy * (now[0] - prev[0]);
            if (cross > 0) {
              a.exited = true;
              this.evacuatedIds.add(a.id);
              this.pushEvent('EXIT_CROSSED', 'INFO', {
                message: `Subject #${a.id} evacuated via ${ex.name}`,
                track_id: a.id,
                zone: ex.exit_id,
              });
            } else {
              a.entered = true;
              this.enteredIds.add(a.id);
              this.pushEvent('UNSAFE_ENTRY', 'CRITICAL', {
                message: `Subject #${a.id} ENTERED hazard area via ${ex.name}`,
                track_id: a.id,
                zone: ex.exit_id,
              });
            }
            break;
          }
        }
      }

      // ---- zone assignment ----
      const prevZone = a.zone;
      a.zone = DEMO_ZONES.find((z) => pointInPolygon(now, z.polygon))?.zone_id ?? null;

      // ---- unsafe movement ----
      if (
        prevZone &&
        a.zone &&
        prevZone !== a.zone &&
        activeHazardZones.has(a.zone) &&
        Math.random() < 0.7
      ) {
        this.pushEvent('UNSAFE_MOVEMENT', 'HIGH', {
          message: `Subject #${a.id} moving toward hazard in ${a.zone}`,
          track_id: a.id,
          from_zone: prevZone,
          to_zone: a.zone,
          confidence: 0.82 + Math.random() * 0.14,
        });
      }
    }

    this.agents = this.agents.filter((a) => !a.exited || this.tick % 3 !== 0 || true);

    // ---- hazard temporal confirmation ----
    for (const [key, hz] of this.hazards) {
      const wasConfirmed = hz.frames >= 15;
      hz.frames += 1;
      hz.conf = Math.min(0.98, hz.conf + (Math.random() - 0.4) * 0.02);
      if (!wasConfirmed && hz.frames >= 15) {
        this.pushEvent(`${hz.type}_DETECTED`, 'CRITICAL', {
          message: `${hz.type} CONFIRMED in ${hz.zone}`,
          zone: hz.zone,
          confidence: hz.conf,
        });
      }
      void key;
    }

    // ---- crowd metrics ----
    const visible = this.agents.filter((a) => !a.exited);
    const zoneMetrics = DEMO_ZONES.map((z) => {
      const people = visible.filter((a) => a.zone === z.zone_id).length;
      const pct = z.capacity > 0 ? (people / z.capacity) * 100 : 0;
      return {
        zone_id: z.zone_id,
        name: z.name,
        people,
        capacity: z.capacity,
        occupancy_percent: Math.round(pct * 10) / 10,
        crowd_level: crowdLevel(pct),
      };
    });

    const hazardEntries: HazardEntry[] = [...this.hazards.values()].map((h) => ({
      type: h.type,
      zone: h.zone,
      confidence: Math.round(h.conf * 1000) / 1000,
      status: h.frames >= 15 ? 'CONFIRMED' : 'DETECTING',
      frames_detected: h.frames,
    }));

    const tracks: TrackedPerson[] = visible.map((a) => ({
      track_id: a.id,
      bbox: [
        Math.round(a.x - 14),
        Math.round(a.y - 30),
        Math.round(a.x + 14),
        Math.round(a.y + 30),
      ],
      confidence: 0.72 + Math.random() * 0.26,
      current_zone: a.zone,
      history: a.history.slice(-14),
      speed_state:
        Math.hypot(a.vx, a.vy) < 0.35
          ? 'STATIONARY'
          : Math.hypot(a.vx, a.vy) > 3
            ? 'RUNNING'
            : 'WALKING',
    }));

    const evacuated = this.evacuatedIds.size;

    return {
      schema_version: '1.0',
      timestamp: new Date().toISOString(),
      camera_id: 'CAM-01',
      camera_status: 'ONLINE',
      fps: 23 + Math.random() * 5,
      source_type: 'file',
      frame_size: [W, H],
      population: {
        total_visible: visible.length,
        evacuated,
        entered: this.enteredIds.size,
        initial_population: this.initialPopulation,
        evacuation_percentage:
          Math.round(((evacuated / Math.max(1, this.initialPopulation)) * 100) * 10) / 10,
        remaining: Math.max(0, this.initialPopulation - evacuated),
        potentially_unaccounted: Math.max(
          0,
          this.initialPopulation - evacuated - visible.length,
        ),
        tracked: tracks.length,
        zones: zoneMetrics,
      },
      hazards: hazardEntries,
      tracks,
    };
  }

  getEvents(): SystemEvent[] {
    return [...this.events];
  }
}

export const simulator = new Simulator();
export const DEMO_FRAME = { width: W, height: H };
