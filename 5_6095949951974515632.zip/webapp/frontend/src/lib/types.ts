/**
 * Type contract mirroring the PS14 / JATAYU CCTV backend
 * (cctv/app/api/server.py + store.py + engines).
 */

export type CrowdLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type HazardType = 'FIRE' | 'SMOKE' | 'DEBRIS';
export type HazardStatus = 'DETECTING' | 'CONFIRMED';
export type CameraStatus = 'ONLINE' | 'OFFLINE' | 'DEGRADED';
export type SourceType = 'webcam' | 'file' | 'rtsp';
export type EventPriority = 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

/** One zone entry inside `state.population.zones` (crowd/engine.py) */
export interface ZoneMetric {
  zone_id: string;
  name: string;
  people: number;
  capacity: number;
  occupancy_percent: number;
  crowd_level: CrowdLevel;
}

/** Confirmed hazard entry inside `state.hazards` (main.py) */
export interface HazardEntry {
  type: HazardType | string;
  zone: string;
  confidence: number;
  status?: HazardStatus;
  frames_detected?: number;
}

export interface PopulationBlock {
  total_visible: number;
  evacuated: number;
  entered: number;
  zones: ZoneMetric[];
  /** optional extras exposed by the patched backend */
  initial_population?: number;
  evacuation_percentage?: number;
  remaining?: number;
  potentially_unaccounted?: number;
  tracked?: number;
}

/** `GET /state` */
export interface SystemState {
  schema_version?: string;
  timestamp: string;
  camera_id: string;
  camera_status?: CameraStatus;
  fps?: number;
  source_type?: SourceType;
  population: PopulationBlock;
  hazards: HazardEntry[];
  /** Live tracked people (patched backend adds this for the overlay) */
  tracks?: TrackedPerson[];
  frame_size?: [number, number];
}

export interface TrackedPerson {
  track_id: number;
  bbox: [number, number, number, number];
  confidence: number;
  current_zone: string | null;
  history?: [number, number][];
  speed_state?: 'STATIONARY' | 'WALKING' | 'RUNNING' | 'UNKNOWN';
}

export type EventType =
  | 'FIRE_DETECTED'
  | 'SMOKE_DETECTED'
  | 'DEBRIS_DETECTED'
  | 'EXIT_CROSSED'
  | 'UNSAFE_MOVEMENT'
  | 'UNSAFE_ENTRY'
  | 'EXIT_BLOCKED'
  | 'CROWD_SURGE'
  | 'CAMERA_OFFLINE'
  | 'SYSTEM';

/** `GET /events` -> { events: SystemEvent[] } */
export interface SystemEvent {
  event_id: string;
  timestamp: string;
  type: EventType | string;
  priority: EventPriority | string;
  data: {
    message?: string;
    zone?: string;
    track_id?: number;
    from_zone?: string;
    to_zone?: string;
    confidence?: number;
    [k: string]: unknown;
  };
  /** local-only flag for acknowledgement in the UI */
  acknowledged?: boolean;
}

/** `GET /zones` (config/zones.json) */
export interface ZoneConfig {
  zone_id: string;
  name: string;
  capacity: number;
  polygon: [number, number][];
  critical?: boolean;
}

/** `GET /exits` (config/exits.json) */
export interface ExitConfig {
  exit_id: string;
  name: string;
  line: [[number, number], [number, number]];
  blocked?: boolean;
}

/** `GET /health` */
export interface HealthResponse {
  status: 'ok' | 'degraded' | string;
  uptime_seconds?: number;
  camera_status?: CameraStatus;
  source_type?: SourceType;
  fps?: number;
  detector?: string;
  version?: string;
}

export interface ConnectionInfo {
  connected: boolean;
  latencyMs: number | null;
  lastSuccess: number | null;
  error: string | null;
  mode: 'LIVE' | 'DEMO';
}

/** Rolling time-series sample kept client-side for charts */
export interface Sample {
  t: number;
  label: string;
  visible: number;
  evacuated: number;
  entered: number;
  hazards: number;
  occupancy: number;
}
