/**
 * JATAYU API client.
 *
 * Talks to the PS14 CCTV FastAPI backend:
 *   GET /health        -> HealthResponse
 *   GET /state         -> SystemState
 *   GET /events        -> { events: SystemEvent[] }
 *   GET /zones         -> ZoneConfig[]
 *   GET /exits         -> ExitConfig[]
 *   GET /video_feed    -> multipart MJPEG stream (used directly as <img src>)
 *   POST /reset        -> resets evacuation counters
 *   POST /config       -> switch video source
 *
 * Every method is defensive: a failure never throws into the render tree,
 * it resolves to `null` and the store flips to DEMO mode.
 */

import type {
  ExitConfig,
  HealthResponse,
  SystemEvent,
  SystemState,
  ZoneConfig,
} from './types';

const STORAGE_KEY = 'jatayu.apiBase';
export const DEFAULT_API_BASE = 'http://127.0.0.1:8000';

export function getApiBase(): string {
  if (typeof window === 'undefined') return DEFAULT_API_BASE;
  const stored = window.localStorage.getItem(STORAGE_KEY);
  return (stored && stored.trim().replace(/\/+$/, '')) || DEFAULT_API_BASE;
}

export function setApiBase(base: string) {
  const clean = base.trim().replace(/\/+$/, '');
  window.localStorage.setItem(STORAGE_KEY, clean || DEFAULT_API_BASE);
}

export function videoFeedUrl(): string {
  // cache-buster so re-mounting the <img> restarts the MJPEG stream
  return `${getApiBase()}/video_feed?t=${Date.now()}`;
}

export interface FetchResult<T> {
  data: T | null;
  latencyMs: number;
  error: string | null;
  status: number;
}

async function request<T>(
  path: string,
  init?: RequestInit & { timeoutMs?: number },
): Promise<FetchResult<T>> {
  const started = performance.now();
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), init?.timeoutMs ?? 6000);

  try {
    const res = await fetch(`${getApiBase()}${path}`, {
      ...init,
      signal: controller.signal,
      headers: { Accept: 'application/json', ...(init?.headers ?? {}) },
      mode: 'cors',
      cache: 'no-store',
    });

    const latencyMs = Math.round(performance.now() - started);

    if (!res.ok) {
      return { data: null, latencyMs, error: `HTTP ${res.status}`, status: res.status };
    }

    const text = await res.text();
    if (!text) return { data: null, latencyMs, error: 'Empty response', status: res.status };

    return { data: JSON.parse(text) as T, latencyMs, error: null, status: res.status };
  } catch (err) {
    const latencyMs = Math.round(performance.now() - started);
    const message =
      err instanceof DOMException && err.name === 'AbortError'
        ? 'Request timed out'
        : err instanceof Error
          ? err.message
          : 'Network error';
    return { data: null, latencyMs, error: message, status: 0 };
  } finally {
    window.clearTimeout(timeout);
  }
}

export const api = {
  health: () => request<HealthResponse>('/health', { timeoutMs: 3500 }),
  state: () => request<SystemState>('/state', { timeoutMs: 5000 }),
  events: () => request<{ events: SystemEvent[] }>('/events', { timeoutMs: 5000 }),
  zones: () => request<ZoneConfig[]>('/zones', { timeoutMs: 5000 }),
  exits: () => request<ExitConfig[]>('/exits', { timeoutMs: 5000 }),

  reset: () =>
    request<{ ok: boolean }>('/reset', {
      method: 'POST',
      timeoutMs: 5000,
    }),

  setSource: (source_type: string, source_path: string) =>
    request<{ ok: boolean }>('/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source_type, source_path }),
      timeoutMs: 8000,
    }),

  saveZones: (zones: ZoneConfig[]) =>
    request<{ ok: boolean }>('/zones', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(zones),
      timeoutMs: 8000,
    }),

  saveExits: (exits: ExitConfig[]) =>
    request<{ ok: boolean }>('/exits', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exits),
      timeoutMs: 8000,
    }),
};
