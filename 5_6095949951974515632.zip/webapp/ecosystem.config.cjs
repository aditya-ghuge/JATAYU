module.exports = {
  apps: [
    {
      name: 'jatayu-frontend',
      cwd: '/home/user/webapp/frontend',
      script: 'npx',
      args: 'vite preview --host 0.0.0.0 --port 3000 --strictPort',
      env: { NODE_ENV: 'production' },
      watch: false,
      instances: 1,
      exec_mode: 'fork',
    },
  ],
};
